export class StatusEffect {
    /**
     * @callback trigger
     * @param {PTActor} actor
     */

    /**
     * @param {string} name 
     * @param {Number} triggerType 
     * @param {trigger} activation
     */
    constructor(name, triggerType, activation, decay, desc, hidden = false) {
        this.name = name;
        this.triggerType = triggerType;
        this.activation = activation;
        this.decay = decay;
        this.hidden = hidden;
        this.desc = desc;
    }
}

export const Triggers = {
    END: 1,
    START: 2,
    ACTION: 3,
    HIT: 4,
    BURST: 5,
    NONE: 6,
    AFTER_DECAY: 7,
    MOVE: 8
}