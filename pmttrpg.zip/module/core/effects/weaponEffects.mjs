import { Effect } from "./effect.mjs";
import { handleNegativeText } from "../../core/effects/effectHelpers.mjs";
import { Conditional, RollContext } from "../combat/rollContext.mjs";
import { pollUserInputOptions } from "../helpers/dialog.mjs";
import { createEffectsMessage } from "../helpers/clash.mjs";
import { getActorToken, getAlliesWithinRadius, getAlliesWithinRadiusOfTarget } from "../../pmttrpg.mjs";
import { pollUserGetGridSpace, pollUserRequestTargeting, requestForcedMovement } from "../combat/movement.mjs";
import { addHazard, HazardNames, HazardStatusEffects, HazardType } from "../combat/hazards.mjs";
import { TargetType } from "../combat/targeting.mjs";
import { getMovementName } from "../status/statusEffects.mjs";

export let weaponEffects = [
    // Dice Manipulation
    new Effect(
        "Dice Power Up",
        (context, count, trigger) => { context.dicePower = Number(context.dicePower) + Number(count); },
        null,
        ["Always Active"]
    ),
    new Effect(
        "Dice Max Up",
        (context, count, trigger) => { 
            let negative = count < 0;
            count = Math.abs(count);

            if (negative) {
                for (let i = 0; i < count; i++) {
                    if (Number(context.diceMax) <= 1) {
                        context.dicePower = Number(context.dicePower) - 1;
                    }
                    else {
                        context.diceMax = Number(context.diceMax) - 1;
                    }
                }
            }
            else {
                context.diceMax = Number(context.diceMax) + Number(count);
            }
        },
        null,
        ["Always Active"]
    ),
    new Effect(
        "Enemy Power Down",
        (context, count, trigger) => {
            context.enemyPowerMod += count * -1;
        },
        (count) => {
            return handleNegativeText(
                "Decrease target's Dice Power by %", 
                "Increase target's Dice Power by %", 
            count);
        },
        ["On Use"], true, 5
    ),
    // Status Effects
    simpleStatusEffect("Burn", false),
    simpleStatusEffect("Frostbite", false),
    simpleStatusEffect("Bleed", false),
    simpleStatusEffect("Rupture", true),
    simpleStatusEffect("Tremor", true),
    simpleStatusEffect("Sinking", true),
    simpleStatusEffect("Poison", false),
    simpleStatusEffect("Heal Inefficiency", false, true),
    simpleStatusEffect("Smoke", false),
    simpleStatusEffect("Nails", false),
    simpleStatusEffect("Paralysis", true),
    simpleStatusEffect("Fragile", true),
    simpleStatusEffect("Stagger Fragile", true),
    simpleStatusEffect("Terror", false),
    new Effect(
        "Inflict [Type] Fragile",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                if (context.flags.includes("DidTypeFragile")) {
                    return;
                }
                context.flags.push("DidTypeFragile");
                let type = await pollUserInputOptions(ctx.actor, "Choose [Type] Fragility to inflict.", [
                    {
                        name: "Slash Fragility",
                        icon: "/status/Slash_Fragility.png"
                    },
                    {
                        name: "Pierce Fragility",
                        icon: "/status/Pierce_Fragility.png"
                    },
                    {
                        name: "Blunt Fragility",
                        icon: "/status/Blunt_Fragility.png"
                    },
                ]);
                data.applyInfliction(type.replace(" ", "_"), 2, true);
            });
        },
        (count) => {
            return `Apply ${Number(count)} [Type] Fragility, chosen on application.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    ),
    simpleStatusEffect("Ruin", false),
    new Effect(
        `Gain Poise`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Poise", -count, false);
        },
        (count) => {
            return handleNegativeText(
                `Gain % [/status/Poise] Poise`,
                `Inflict % [/status/Poise] Poise`, 
            count);
        },
        ["Clash Win", "Clash Lose"],
    ),
    new Effect(
        `Gain Healing Efficiency`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Heal_Efficiency", -count, false);
        },
        (count) => {
            return handleNegativeText(
                `Gain % [/status/Heal_Efficiency] Healing Efficiency`,
                `Inflict % [/status/Heal_Efficiency] Healing Efficiency`, 
            count);
        },
        ["Clash Win", "Clash Lose"],
    ),
    // Misc Effects
    new Effect(
        "Multi-hit",
        (context, count, trigger) => { 
            context.conditionals.push(new Conditional("Multi-Hit", `Lose 2 Dice Power. Replace attack with ${Number(count) + 1} attacks.`, (context) => {
                context.dicePower = Number(context.dicePower) - 2;
                context.diceCount = Math.min(Number(context.diceCount) + count, 3);
            }));
        },
        null,
        ["Always Active"],
        false,
        2
    ),
    // Melee Only
    new Effect(
        "Double-Edged",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Bleed", 2, false);
            context.triggers["Clash Lose"].applyInfliction("Bleed", -2, false);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Bleed] Bleed", "Gain 2 [/status/Bleed] Bleed", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        "Vibrating",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Tremor", 2, true);
            context.triggers["Clash Lose"].applyInfliction("Tremor", -2, true);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Tremor] Tremor next round", "Gain 2 [/status/Tremor] Tremor next round", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        "Chilling",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Frostbite", 2, false);
            context.triggers["Clash Lose"].applyInfliction("Frostbite", -2, false);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Frostbite] Frostbite", "Gain 2 [/status/Frostbite] Frostbite", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        "Overheated",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Burn", 2, false);
            context.triggers["Clash Lose"].applyInfliction("Burn", -2, false);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Burn] Burn", "Gain 2 [/status/Burn] Burn", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        "Smogged",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Smoke", 2, false);
            context.triggers["Clash Lose"].applyInfliction("Smoke", -2, false);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Smoke] Smoke", "Gain 2 [/status/Smoke] Smoke", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        "Addictive Spite",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Poison", 2, false);
            context.triggers["Clash Lose"].applyInfliction("Poison", -2, false);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Poison] Poison", "Gain 2 [/status/Poison] Poison", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        "Terror",
        (context, count, trigger) => { 
            context.triggers["Clash Win"].applyInfliction("Terror", 2, false);
            context.triggers["Clash Lose"].applyInfliction("Terror", -2, false);
        },
        (count) => {
            return [null, "Inflict 2 [/status/Terror] Terror", "Gain 2 [/status/Terror] Terror", null, null];
        },
        ["Always Active"],
        false, 1, true
    ),
    new Effect(
        `Gain Haste`,
        (context, count, trigger) => {
            if (count < 0) {
                context.triggers[trigger].applyInfliction("Bind", count, true);
            }
            else {
                context.triggers[trigger].applyInfliction("Haste", -count, true);
            }
        },
        (count) => {
            return handleNegativeText(
                `Gain % [/status/Haste] Haste next round`,
                `Gain % [/status/Bind] Bind next round`, 
            count);
        },
        ["Clash Win", "Clash Lose"], true, 5
    ),
    new Effect(
        `Increase Range`,
        (context, count, trigger) => {
            context.range += 1;
        },
        null,
        ["Always Active"],
        false,
        1
    ),
    new Effect(
        `Extension Grip`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Extension Grip [C]", `Spend 4 Charge to increase range by 1 SQR.`, (context) => {
            }, [{ cost: 4, status: "Charge"}], "Extension Grip [O]"));

            context.conditionals.push(new Conditional("Extension Grip [O]", `Spend 1 Overcharge to increase range by 2 SQR.`, (context) => {
            }, [{ cost: 1, status: "Overcharge"}], "Extension Grip [C]"));
        },
        (count) => {
            return [null, null, null, "May spend 4 [/status/Charge] Charge to increase range by 1 SQR, or 1 [/status/Overcharge] Overcharge to increase by 2 SQR.", null];
        },
        ["Always Active"],
        false,
        1,
        true
    ),
    new Effect(
        `Extra DMG Type`,
        (context, count, trigger) => {
            
        },
        null,
        ["Always Active"],
        false,
        2
    ),
    new Effect(
        `Inflict Bind`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Bind", count, true);
        },
        (count) => {
            return `Inflict ${Number(count)} [/status/Bind] Bind next round.`
        },
        ["Clash Win", "Clash Lose"],
        false
    ),
    new Effect(
        `Retracting Cable`,
        (context, count, trigger) => {
            
        },
        null,
        ["Always Active"],
        false,
        1
    ),
    markerEffect("Throwing Weapon", false, 1),
    // Ranged Effects
    new Effect(
        `Extra Range`,
        (context, count, trigger) => {
            
        },
        null,
        ["Always Active"],
        true,
        5
    ),
    // Charge Effects
    new Effect(
        `Gain Charge`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Charge", -count, false);
        },
        (count) => {
            return `Gain ${Math.abs(count)} [/status/Charge] Charge`;
        },
        ["On Use"],
        false,
        6
    ),
    new Effect(
        `Power Engine`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Power Engine [C]", `Spend 8 Charge to gain 1 Dice Power.`, (context) => {
                context.dicePower = Number(context.dicePower) + 1;
            }, [{ cost: 8, status: "Charge"}], "Power Engine [O]"));

            context.conditionals.push(new Conditional("Power Engine [O]", `Spend 1 Overcharge to gain 2 Dice Power`, (context) => {
                context.dicePower = Number(context.dicePower) + 2;
            }, [{ cost: 1, status: "Overcharge"}], "Power Engine [C]"));
        },
        (count) => {
            return [null, null, null, "May spend 8 [/status/Charge] Charge to gain 1 Dice Power, or 1 [/status/Overcharge] Overcharge to gain 2 Dice Power.", null];
        },
        ["Always Active"],
        false,
        1, true
    ),
    new Effect(
        `Barrier Ionization`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Barrier Ionization [C]", `Spend 3 Charge to gain 1 Charge Barrier.`, (context) => {
                context.triggers[trigger].applyInfliction("Charge_Barrier", -1, false);
            }, [{ cost: 3, status: "Charge"}], "Barrier Ionization [O]"));

            context.conditionals.push(new Conditional("Barrier Ionization [O]", `Spend 1 Overcharge to gain 3 Charge Barrier`, (context) => {
                context.triggers[trigger].applyInfliction("Charge_Barrier", -3, false);
            }, [{ cost: 1, status: "Overcharge"}], "Barrier Ionization [C]"));
        },
        (count) => {
            return "May spend 3 [/status/Charge] Charge to gain 1 [/status/Charge_Barrier] Charge Barrier or 1 [/status/Overcharge] Overcharge to gain 3 [/status/Charge_Barrier] Charge Barrier.";
        },
        ["Clash Win", "Clash Lose"],
        false,
        1
    ),
    new Effect(
        `Refractor`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Refractor [C]", `Spend 4 Charge to inflict +1 of all [Status]+ compatible effects.`, (context) => {
                context.flags.push("Refractor-C");
            }, [{ cost: 4, status: "Charge"}], "Refractor [O]"));

            context.conditionals.push(new Conditional("Refractor [O]", `Spend 1 Overcharge to inflict +3 of all [Status]+ compatible effects.`, (context) => {
                context.flags.push("Refractor-O");
            }, [{ cost: 1, status: "Overcharge"}], "Refractor [C]"));
        },
        (count) => {
            return "May spend 4 [/status/Charge] Charge to inflict +1 of all [Status]+ compatible effects, or 1 [/status/Overcharge] Overcharge to inflict +3.";
        },
        ["On Use"],
        false,
        1
    ),
    new Effect(
        `Galvanic Pulse`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Galvanic Pulse [C]", `Spend 10 Charge to inflict 1 Feeble or 1 Disarm.`, async (context) => {
                let status = await pollUserInputOptions(context.actor, "Choose Galvanic Pulse status effect!", [
                    {
                        name: "Feeble",
                        icon: "/status/Feeble.png"
                    },
                    {
                        name: "Disarm",
                        icon: "/status/Disarm.png"
                    }
                ]);
                context.triggers[trigger].applyInfliction(status, 1, false);
            }, [{ cost: 10, status: "Charge"}], "Galvanic Pulse [O]"));

            context.conditionals.push(new Conditional("Galvanic Pulse [O]", `Spend 1 Overcharge to inflict 1 Feeble and 1 Disarm.`, (context) => {
                context.triggers[trigger].applyInfliction("Feeble", 1, false);
                context.triggers[trigger].applyInfliction("Disarm", 1, false);
            }, [{ cost: 1, status: "Overcharge"}], "Galvanic Pulse [C]"));
        },
        (count) => {
            return "May spend 10 [/status/Charge] Charge to inflict 1 [/status/Feeble] Feeble or 1 [/status/Disarm] Disarm immediately, or 1 [/status/Overcharge] Overcharge to apply both.";
        },
        ["Clash Win", "Clash Lose"],
        false,
        1
    ),
    new Effect(
        `Countercurrent`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Countercurrent [C]", `Spend 4 Charge to inflict 1 Paralysis.`, (context) => {
                context.triggers[trigger].applyInfliction("Paralysis", 1, false);
            }, [{ cost: 4, status: "Charge"}], "Countercurrent [O]"));

            context.conditionals.push(new Conditional("Countercurrent [O]", `Spend 1 Overcharge to inflict 2 Paralysis.`, (context) => {
                context.triggers[trigger].applyInfliction("Paralysis", 2, false);
            }, [{ cost: 1, status: "Overcharge"}], "Countercurrent [C]"));
        },
        (count) => {
            return "May spend 4 [/status/Charge] Charge to inflict 1 [/status/Paralysis] Paralysis immediately, or 1 [/status/Overcharge] Overcharge to inflict 2.";
        },
        ["Clash Win", "Clash Lose"],
        false,
        1
    ),
    new Effect(
        `Magnetic Drive`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Magnetic Drive [C]", `Spend 6 Charge to push the target 1 SQR.`, (context) => {
                context.triggers[trigger].modify.push(async (ctx, data) => {
                    createEffectsMessage(context.target.name, `[/status/Aggro] Is pushed 1 SQR away from ${context.actor.name} by Magnetic Drive!`);
                    await requestForcedMovement(context.actor, context.target, context.target, 1, true, true);
                });
            }, [{ cost: 6, status: "Charge"}], "Magnetic Drive [O]"));

            context.conditionals.push(new Conditional("Magnetic Drive [O]", `Spend 1 Overcharge to push the target 2 SQR.`, (context) => {
                context.triggers[trigger].modify.push(async (ctx, data) => {
                    createEffectsMessage(context.target.name, `[/status/Aggro] Is pushed 2 SQR away from ${context.actor.name} by Magnetic Drive!`);
                    await requestForcedMovement(context.actor, context.target, context.target, 2, true, true);
                });
            }, [{ cost: 1, status: "Overcharge"}], "Magnetic Drive [C]"));
        },
        (count) => {
            return "May spend 6 [/status/Charge] Charge to push the target 1 SQR, or 1 [/status/Overcharge] Overcharge to push them 2.";
        },
        ["Clash Win"],
        false,
        1, false, true
    ),
    markerEffect("Charge Ammo", false, 1),
    markerEffect("Coagulated Bullets", false, 1),
    new Effect(
        `Loaded Magnet`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Loaded Magnet [C]", `Spend 6 Charge to pull the target ${Number(count)} SQR.`, (context) => {
                context.triggers[trigger].modify.push(async (ctx, data) => {
                    createEffectsMessage(context.target.name, `[/status/Aggro] Is pulled ${count} SQR towards ${context.actor.name} by Loaded Magnet!`);
                    await requestForcedMovement(context.actor, context.target, context.target, count, true, true);
                });
            }, [{ cost: count * 3, status: "Charge"}], "Loaded Magnet [O]"));

            context.conditionals.push(new Conditional("Loaded Magnet [O]", `Spend 1 Overcharge to pull the target ${Number(count) * 3} SQR.`, (context) => {
                context.triggers[trigger].modify.push(async (ctx, data) => {
                    createEffectsMessage(context.target.name, `[/status/Aggro] Is pulled ${count * 3} SQR towards ${context.actor.name} by Loaded Magnet!`);
                    await requestForcedMovement(context.actor, context.target, context.target, count * 3, true, true);
                });
            }, [{ cost: count, status: "Overcharge"}], "Loaded Magnet [C]"));
        },
        (count) => {
            return `May spend ${3 * count} [/status/Charge] Charge to pull the target ${Number(count)} SQR, or ${Number(count)} [/status/Overcharge] Overcharge to pull them ${Number(count) * 3}.`;
        },
        ["On Use"],
        false,
        5, false, true
    ),
    //
    new Effect(
        `Shattershield`,
        (context, count, trigger) => {},
        (count) => {
            return `Inflict 1 [Type] Fragile corresponding to the attack type if the target used a Defensive die.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Backburner`,
        (context, count, trigger) => {
            context.triggers["Clash Win"].modify.push((ctx, data) => {
                let allies = getAlliesWithinRadiusOfTarget(context.actor, context.target, 1);

                if (allies.length > 0) {
                    data.applyInfliction("Burn", 2, false);
                }
            });
        },
        (count) => {
            return `Inflict 2 [/status/Burn] Burn if an ally is adjacent to the target.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Backstabber`,
        (context, count, trigger) => {},
        (count) => {
            return `Inflict 3 [/status/Bleed] Bleed if this attack went unopposed.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Duelist Sidearm`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Duelist Sidearm", `Gain 3 Poise if dual wielding.`, (context) => {
                context.triggers["Clash Win"].modify.push((ctx, data) => {
                    data.applyInfliction("Poise", -3, false);
                });
            }, [], null));
        },
        (count) => {
            return `Gain 3 [/status/Poise] Poise if this attack was due to dual wielding.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Fencer's Implement`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Fencer's Implement", `Gain 2 Poise if not dual wielding.`, (context) => {
                context.triggers["Clash Win"].modify.push((ctx, data) => {
                    data.applyInfliction("Poise", -2, false);
                });
            }, [], null));
        },
        (count) => {
            return `Gain 2 [/status/Poise] Poise if this attack was not due to dual wielding.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Friction Charger`,
        (context, count, trigger) => {
            if (context.target && context.target.getStatusCount("Burn") > 0) {
                context.triggers["Clash Win"].applyInfliction("Charge", -2, false);
            }
        },
        (count) => {
            return `Gain 2 [/status/Charge] Charge if the target has [/status/Burn] Burn.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Friction Charger`,
        (context, count, trigger) => {
            if (context.target && context.target.getStatusCount("Burn") > 0) {
                context.triggers["Clash Win"].applyInfliction("Charge", -2, false);
            }
        },
        (count) => {
            return `Gain 2 [/status/Charge] Charge if the target has [/status/Burn] Burn.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Frozen Blade`,
        (context, count, trigger) => {
            if (context.actor.getStatusCount("Frostbite") >= 4) {
                context.triggers["Clash Win"].stHeal -= 4;
            }
        },
        (count) => {
            return `Deal 4 ST damage if the user has 4+ [/status/Frostbite] Frostbite.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Hooked Barbs`,
        (context, count, trigger) => {},
        (count) => {
            return `Inflict 4 [/status/Rupture] Rupture and 2 [/status/Tremor] Tremor if this attack went unopposed.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Nerve Tap`,
        (context, count, trigger) => {
            context.triggers["Devastating Hit"].applyInfliction("Critical", 1, false);
        },
        (count) => {
            return `Gain 1 [/status/Critical] Critical.`;
        },
        ["Devastating Hit"],
        false, 1, false, false
    ),
    new Effect(
        `Panic Guard`,
        (context, count, trigger) => {},
        (count) => {
            return `May spend a use to gain 2 [/status/Protection] Protection and [/status/Stagger_Protection] Stagger Protection immediately.`;
        },
        ["Clash Lose"],
        false, 1, false, false
    ),
    new Effect(
        `Spasmic Loader`,
        (context, count, trigger) => {
            context.triggers["Clash Win"].modify.push((ctx, data) => {
                if (ctx.actor.isMarkedTarget(ctx.target)) {
                    data.applyInfliction("Tremor", 2, true);
                    data.applyInfliction("Rupture", 2, true);
                }
            });
        },
        (count) => {
            return `Inflict 2 [/status/Rupture] Rupture and [/status/Tremor] Tremor next round if the target is Marked.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Bear Trap`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Bear Trap", `Inflict 1 Bind and 3 Bleed on opportunity attack.`, (context) => {
                context.triggers["Clash Win"].modify.push((ctx, data) => {
                    data.applyInfliction("Bind", 1, false);
                    data.applyInfliction("Bleed", 2, false);
                });
            }, [], null));
        },
        (count) => {
            return `Inflict 1 [/status/Bind] Bind and 2 [/status/Bleed] Bleed if this is an Opportunity Attack.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Electrified Barrel`,
        (context, count, trigger) => {
            context.triggers["Tremor Burst"].applyInfliction("Paralysis", 1, true);
            context.triggers["Rupture Burst"].applyInfliction("Paralysis", 1, true);
        },
        (count) => {
            return `Inflict 1 [/status/Paralysis] Paralysis next round if [/status/Rupture] Rupture or [/status/Tremor] Tremor were bursted.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Rib Breaker`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Rib Breaker", `Inflict 4 Bleed if Force Damage is inflicted.`, (context) => {
                context.triggers["Clash Win"].modify.push((ctx, data) => {
                    data.applyInfliction("Bleed", 4, false);
                });
            }, [], null));
        },
        (count) => {
            return `Inflict 4 [/status/Bleed] Bleed if the attack causes Force Damage.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Snagging Thorns`,
        (context, count, trigger) => {},
        (count) => {
            return `May apply Rupture Pause if a reaction converted this to a Block.`;
        },
        ["Clash Lose"],
        false, 1, false, false
    ),
    new Effect(
        `Superpositioner`,
        (context, count, trigger) => {
            context.triggers["Tremor Burst"].applyInfliction("Rupture", 2, true);
            context.triggers["Rupture Burst"].applyInfliction("Tremor", 2, true);
        },
        (count) => {
            return `On [/status/Rupture] Rupture or [/status/Tremor] Tremor burst, apply 2 of the opposite status next round.`;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Ground Rumbler`,
        (context, count, trigger) => {},
        (count) => {
            return null;
        },
        ["Clash Win"],
        false, 1, false, false
    ),
    new Effect(
        `Hooked Lining`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Hooked Lining", `Convert 3 Bleed on target into 1 Hemorrhage.`, (context) => {
                context.triggers["Clash Win"].modify.push(async (ctx, data) => {
                    if (ctx.target.getStatusCount("Bleed") >= 3) {
                        data.applyInfliction("Hemorrhage", 1, false);
                        await ctx.target.reduceStatus("Bleed", 3);
                    }
                });
            }, [], null));
        },
        (count) => {
            return `Convert 3 [/status/Bleed] Bleed on target into 1 [/status/Hemorrhage] Hemorrhage.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        `Laser Pointer`,
        (context, count, trigger) => {},
        (count) => {
            return `Reduce the [/status/Critical] Critical die to a d8.`;
        },
        ["On Use"],
        false, 1, false, false
    ),
    new Effect(
        `Severing Blade`,
        (context, count, trigger) => {
            
        },
        (count) => {
            return `Treat the target's resistance as 1 tier higher.`;
        },
        ["On Crit"],
        false, 1, false, true
    ),
    //
    markerEffect("Ballistic", false, 1),
    new Effect(
        'Volatile',
        (context, count, trigger) => {
            context.events["Round End"].push(async (context) => {
                await context.actor.takeDamageStatus(count, "", "SP", "Takes %DMG% SP damage from their volatile weapon! (%PSP% -> %SP%)");
            });
        },
        (count) => {
            return `Lose ${count} SP if this weapon is held.`
        },
        ["Round End"], false, 99999, false, true
    ),
    new Effect(
        `Charged Blade`,
        (context, count, trigger) => {
        },
        (count) => {
            return `Consume ${1 + Number(count)} [/status/Charge] Charge to use this weapon.`;
        },
        ["On Use"],
        false, 5, false, false
    ),
    new Effect(
        `Blood-Tinged Blade`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Blood-Tinged Blade", `Consume 10 Bloodfeast to repeat attack.`, (context) => {
                context.events["Clash Win"].push(async (context) => {
                    createEffectsMessage(context.actor.name, `Spends 10 [/status/Bloodfeast] Bloodfeast to trigger Blood-Tinged Blade!`);
                })
            }, [
                {
                    status: "Bloodfeast",
                    cost: 10
                }
            ], null));
        },
        (count) => {
            return `May spend 10 [/status/Bloodfeast] Bloodfeast to attack another target with this weapon. This extra attack may not use skills.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        "Bloodied Amplifier",
        (context, count, trigger) => {
            if (context.actor == null) {
                return;
            }

            let consumed = Math.min(Math.floor(context.actor.getSpentBloodfeast() / 20), 3);
            if (consumed > 0) {
                context.dicePower = Number(context.dicePower) + Number(consumed); 
            }
        },
        (count) => {
            return `Gain 1 Dice Power for every 20 [/status/Consumed_Bloodfeast] Consumed Bloodfeast, up to ${count}.`;
        },
        ["On Use"]
    ),
    new Effect(
        "Combat Medic",
        (context, count, trigger) => { 
            context.triggers[trigger].applyInfliction("Heal_Efficiency", -2, false);
        },
        (count) => {
            return `Gain 2 [/status/Heal_Efficiency] Heal Efficiency.`;
        },
        ["Clash Win", "Clash Lose"], false, 1
    ),
    simpleStatusEffect("Poison", false, true),
    new Effect(
        `Pitiful`,
        (context, count, trigger) => {
        },
        (count) => {
            return `If [/status/Sinking] Sinking is burst on self, inflict next round [/status/Sinking] Sinking equal to half the stack to the attacker.`;
        },
        ["Clash Lose"],
        false, 1,
    ),
    hazardousCreation(HazardType.BROKEN_GLASS),
    hazardousCreation(HazardType.EXHAUST_FUMES),
    hazardousCreation(HazardType.CHILLING_FROST),
    hazardousCreation(HazardType.EXPOSED_FIRE),
    hazardousCreation(HazardType.TOXIC_FUMES),
    new Effect(
        "Smokeshot",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let c = context.getRange();
                let tiles = await pollUserRequestTargeting(context.actor, TargetType.MULTI_GRID, {
                    maxSelections: c,
                    originToken: getActorToken(context.actor),
                    maxRange: c,
                    enforceRange: true,
                    requireLOS: true
                });
                
                await addHazard(HazardType.EXHAUST_FUMES, 3, context.actor.system.id, tiles);
            });
        },
        (count) => {
            return `Create a trail of [/status/Smoke] Exhaust Fumes along the projectile's path.`
        },
        ["On Use"], false, 1, false, true
    ),
    new Effect(
        "Smoke Cartridge",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let smoke = context.actor.getStatusCount("Smoke");
                smoke = Math.floor(smoke / 2);
                if (smoke < 1) smoke = 1;

                await context.actor.reduceStatus("Smoke", smoke);
                context.triggers["Clash Win"].applyInfliction("Smoke", smoke);

                createEffectsMessage(context.actor.name, `Spends ${smoke} [/status/Smoke] Smoke to create ammo!`);
            });
        },
        (count) => {
            return `Spend half of [/status/Smoke] Smoke on self to fire this weapon. Inflict [/status/Smoke] Smoke equal to the amount spent on hit.`
        },
        ["On Use"], false, 1
    ),
    new Effect(
        "Power Chord",
        (context, count, trigger) => {
            if (context.target == null) {
                return;
            }

            if (context.checkResonance()) {
                context.dicePower = Number(context.dicePower + count);
            }
        },
        (count) => {
            return `Gain ${count} Dice Power during [/status/Rhythm] Rhythm Resonance`
        },
        ["On Use"], false, 2
    ),
    risingSymphony("Bleed"),
    risingSymphony("Frostbite"),
    risingSymphony("Rupture"),
    risingSymphony("Tremor"),
    new Effect("Sanity Only",
        (context, count, trigger) => {

        },
        (count) => {
            return `Do not deal damage. Target loses 5 SP.`;
        },
        ["Clash Win"], false, 1
    ),
    simpleStatusEffect("Deathrite [Haste]", false, false),
    simpleStatusEffect("Deathrite [Prey]", false, false),
    simpleStatusEffect("Deathrite [Stolen]", false, false),
]

export function setWeaponEffects(array) {
    weaponEffects = array;
}

function risingSymphony(status) {
    return new Effect(
        `Rising Symphony - ${status}`,
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                if (context.actor.getStatusCount("Rhythm") == count) {
                    data.applyInfliction(status, count, false);
                }
            });
        },
        (count) => {
            return `During the [/status/Rhythm] ${getMovementName(count)} movement, inflict ${count} [/status/${status}] ${status}`;
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    )
}

function hazardousCreation(hazard) {
    let name = HazardStatusEffects[hazard];
    let hazardName = HazardNames[hazard];

    return new Effect(
        `Hazardous Creation - ${name}`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional("Hazardous Creation", "Uses Hazardous Creation for this attack", (context) => {
                context.flags.push("Hazardous Creation");
                console.log('applied hazardous');
                context.events["Clash Win"].push(async (context) => {
                    console.log('event fired');
                    let c = 4 * count;
                    let tiles = await pollUserRequestTargeting(context.actor, TargetType.MULTI_GRID, {
                        maxSelections: c,
                        originToken: getActorToken(context.target),
                        enforceRange: false,
                        requireLOS: true
                    });
                    
                    await addHazard(hazard, 3, context.actor.system.id, tiles);
                });
            }, [], []));
        },
        (count) => {
            return `May reduce damage dealt by 50% to create up to ${4 * count} tiles of [/status/${name}] ${hazardName} around the target.`
        },
        ["Clash Win"], false, 5, false, true
    );
}

function simpleStatusEffect(status, nextRound, allowNegative) {
    let str = nextRound ? " next round" : "";
    return new Effect(
        `Inflict ${status}`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction(status, count, nextRound);
        },
        (count) => {
            return handleNegativeText(
                `Inflict % [/status/${status.replace(" ", "_")}] ${status}` + str, 
                `Gain % [/status/${status.replace(" ", "_")}] ${status}` + str, 
            count);
        },
        ["Clash Win", "Clash Lose"],
        allowNegative, status == "Rupture" || status == "Poison" ? 6 : 5
    );
}

function markerEffect(name, negative = false, count = 1) {
    return new Effect(
        name,
        (context, count, trigger) => { },
        null,
        ["Always Active"],
        negative,
        count
    );
}