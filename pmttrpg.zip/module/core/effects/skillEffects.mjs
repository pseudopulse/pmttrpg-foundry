import { Effect } from "./effect.mjs";
import { handleNegativeText } from "../../core/effects/effectHelpers.mjs";
import { createEffectsMessage } from "../helpers/clash.mjs";
import { pollDistributeStatus, pollUserInputConfirm, pollUserInputOptions, pollUserInputText } from "../helpers/dialog.mjs";
import { findActorsOfTeam, getActorTeam, getActorToken, getAlliesWithinRadius, getAlliesWithinRadiusOfTarget, getCharactersWithinRadius, getEnemiesWithinRadius, getTokenCenter, scale } from "../../pmttrpg.mjs";
import { Conditional } from "../combat/rollContext.mjs";
import { findByID } from "../helpers/netmsg.mjs";
import { getRollContextFromData } from "../../documents/item.mjs";
import { getCombatantTokens } from "../combat/combatState.mjs";
import { pollUserRequestTargeting, requestForcedMovement, teleportToken } from "../combat/movement.mjs";
import { TargetType } from "../combat/targeting.mjs";

export let skillEffects = [
    new Effect(
        "Dice Power Up",
        (context, count, trigger) => { 
            context.dicePower = Number(context.dicePower) + Number(count);
            context.skillDicePower = Number(context.skillDicePower) + Number(count);
        },
        (count) => {
            return [Number(count) < 0 ? `Reduce Dice Power by ${Math.abs(count)}` : `Increase Dice Power by ${Number(count)}`, null, null]
        },
        ["Always Active"],
        true,
        5,
        true
    ),
    new Effect(
        "Dice Max Up",
        (context, count, trigger) => { 
            let negative = count < 0;
            count = Math.abs(count);

            if (negative) {
                for (let i = 0; i < count; i++) {
                    if (Number(context.diceMax) <= 1) {
                        context.dicePower = Number(context.dicePower) - 1;
                        context.skillDicePower = Number(context.skillDicePower) - 1;
                    }
                    else {
                        context.diceMax = Number(context.diceMax) - 1;
                    }
                }
            }
            else {
                context.diceMax = Number(context.diceMax) + Number(count);
            }
        },
        null,
        ["Always Active"]
    ),
    new Effect(
        "Enemy Power Down",
        (context, count, trigger) => {
            context.enemyPowerMod += count * -1;
        },
        (count) => {
            return handleNegativeText(
                "Decrease target's Dice Power by %", 
                "Increase target's Dice Power by %", 
            count);
        },
        ["On Use"], true, 5
    ),
    skillVigorEffect("Bind", 1, 0),
    skillBonusEffect("Bind", 0),
    new Effect(
        "Single Strike",
        (context, count, trigger) => {
            if (context.actor && !context.flags.includes("Single Strike")) {
                let reactions = context.actor.system.reactions;
                context.dicePower = Number(context.dicePower) + Math.clamp(reactions, 2, 6);
                context.skillDicePower = Number(context.skillDicePower) + Math.clamp(reactions, 2, 6);
            }

            context.events["On Use"].push(async (context) => {
                await context.actor.update({ "system.reactions": 0 }, { diff: false });
                createEffectsMessage(context.actor.name, `${context.actor.name} burns all of their reactions to empower the attack!`);
            });
        },
        (count) => {
            return `Forfeit all reactions and gain Dice Power equal to spent reactions (min 2, max 6)`;
        },
        ["On Use"],
        false,
        1, false, true
    ),
    new Effect(
        "Overcoming Crisis",
        (context, count, trigger) => { 
            if (context.actor != null && context.actor.system.attributes.health.value < context.actor.system.attributes.health.max * (1 - (0.2 * count))) {
                context.dicePower = Number(context.dicePower) + Number(count);
                context.skillDicePower = Number(context.skillDicePower) + Number(count);
            }
        },
        (count) => {
            return `Gain ${Number(count)} Dice Power if HP is less than ${(1 - (0.2 * count)) * 100}%`;
        },
        ["On Use"],
        false,
        4
    ),
    new Effect(
        "Overcoming Madness",
        (context, count, trigger) => { 
            let sp = 0;
            let spm = 0;
            if (context.actor != null) {
                sp = context.actor.getSP();
                spm = context.actor.getMaxSP();
            }
            if (context.actor != null && sp <= spm * (1 - (0.2 * count))) {
                context.dicePower = Number(context.dicePower) + Number(count);
                context.skillDicePower = Number(context.skillDicePower) + Number(count);
            }
        },
        (count) => {
            return `Gain ${Number(count)} Dice Power if SP is less than ${Math.ceil((1 - (0.2 * count)) * 100)}%`;
        },
        ["On Use"],
        false,
        4
    ),
    new Effect(
        "Overheat",
        (context, count, trigger) => { 
            context.dicePower = Number(context.dicePower) + 2;
            context.skillDicePower = Number(context.skillDicePower) + 2;
        },
        (count) => {
            return `Increase Dice Power by 2. Weapon becomes unusable until the end of next round.`
        },
        ["On Use"], false, 1
    ),
    markerEffect("Ignore Power", false, 1, "On Use", count => `Negate Dice Power changes on self and target, except from this skill`),
    //
    simpleStatusEffect("Fragile", true, true),
    simpleStatusEffect("Stagger Fragile", true, true),
    new Effect(
        "Inflict [Type] Fragile",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let type = await pollUserInputOptions(ctx.actor, "Choose [Type] Fragility to inflict.", [
                    {
                        name: "Slash Fragility",
                        icon: "/status/Slash_Fragility.png"
                    },
                    {
                        name: "Pierce Fragility",
                        icon: "/status/Pierce_Fragility.png"
                    },
                    {
                        name: "Blunt Fragility",
                        icon: "/status/Blunt_Fragility.png"
                    },
                ]);
                data.applyInfliction(type.replace(" ", "_"), 2, true);
            });
        },
        (count) => {
            return `Apply ${Number(count)} [Type] Fragility next round, chosen on application.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    ),
    simpleStatusEffect("Paralysis", true, true),
    simpleStatusEffect("Feeble", true, false),
    simpleStatusEffect("Disarm", true, false),
    markerEffect("Instant Bind", false, 1, "On Use", (count) => {
        return 'All [/status/Bind] Bind infliction is resolved instantly.'
    }),
    simpleStatusEffect("Bind", true, false),
    new Effect(
        "Press Advantage",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let bind = ctx.target.getStatusCount("Bind");
                if (bind <= 0) {
                    return;
                }

                let type = await pollUserInputOptions(ctx.actor, "Choose [Type] Fragility to inflict.", [
                    {
                        name: "Slash Fragility",
                        icon: "/status/Slash_Fragility.png"
                    },
                    {
                        name: "Pierce Fragility",
                        icon: "/status/Pierce_Fragility.png"
                    },
                    {
                        name: "Blunt Fragility",
                        icon: "/status/Blunt_Fragility.png"
                    },
                ]);

                data.applyInfliction(type.replace(" ", "_"), Math.max(bind / 2, 1), true);
            });
        },
        (count) => {
            return `Apply [Type] Fragility next round, chosen on application, equal to half the target's [/status/Bind] Bind.`
        },
        ["Clash Win", "Clash Lose"],
        false, 1, false, true
    ),
    new Effect(
        "Suppress",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let bind = ctx.target.system.reactions;
                if (bind > 0) {
                    data.applyInfliction("Bind", bind, true);
                }
            });
        },
        (count) => {
            return `Apply [/status/Bind] Bind next round equal to the target's remaining reactions.`
        },
        ["Clash Win", "Clash Lose"],
        false, 1, false, true
    ),
    simpleStatusEffect("Burn", false, true),
    markerEffect("Burn+", false, 3),
    skillVigorEffect("Burn", 2, 3),
    skillBonusEffect("Burn", 3),
    new Effect(
        "Detonate",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.target.fireStatusEffect("Burn");
            });
        },
        (count) => {
            return `Trigger [/status/Burn] Burn on target.`;
        },
        ["Clash Win"],
        false,
        1, false, true
    ),
    new Effect(
        "Smokey Detonate",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.target.fireStatusEffect("Burn");
                let burn = context.target.getStatusCount("Burn");

                if (burn > 0) {
                    let smoke = context.target.getStatusCount("Smoke");
                    await context.target.applyStatus("Smoke", burn);
                    createEffectsMessage(context.target.name, `Gains ${burn} [/status/Smoke] Smoke from Smokey Detonate! (${smoke} -> ${smoke + burn})`);
                }
            });
        },
        (count) => {
            return `Trigger [/status/Burn] Burn on target, then inflict [/status/Smoke] Smoke equal to remaining [/status/Burn] Burn.`;
        },
        ["Clash Win"],
        false,
        1, false, true
    ),
    statusPauseEffect("Renewed Blaze", 1),
    new Effect(
        "Fireball",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let burn = context.target.getStatusCount("Burn");

                if (burn > 0) {
                    applyInAoe(context.target, count, async (actor) => {
                        if (actor == context.target) {
                            return;
                        }
                        
                        await actor.takeDamageStatus(burn, "Burn", "HP", `[/status/Burn] Burns for %DMG% HP damage from Fireball! (%PHP% -> %HP%)`);
                    }, null);
                    
                    await context.target.fireStatusEffect("Burn");
                }
            });
        },
        (count) => {
            return `Trigger [/status/Burn] Burn on target and deal damage equal to [/status/Burn] Burn to all characters within ${Number(count)} SQR of the target.`;
        },
        ["Clash Win"],
        false,
        5, false, true
    ),
    statusPauseEffect("Dark Flame", 1),
    //
    simpleStatusEffect("Frostbite", false, true),
    markerEffect("Frostbite+", false, 3),
    skillVigorEffect("Frostbite", 2, 1),
    skillBonusEffect("Frostbite", 3),
    statusPauseEffect("Freezer Burn", 1),
    new Effect(
        "Cold Snap",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let paused = context.target.getStatusCount("Deep_Chill") > 0;
                await context.target.fireStatusEffect("Frostbite");

                if (!paused) {
                    await context.target.setStatus("Frostbite", 0);
                }
            });
        },
        (count) => {
            return `Trigger [/status/Frostbite] Frostbite on target, then clear all [/status/Frostbite] Frostbite.`;
        },
        ["Clash Win"],
        false,
        1, false, true
    ),
    statusPauseEffect("Deep Chill", 1),
    new Effect(
        "Shatter",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let frostbite = Math.min(ctx.target.getStatusCount("Frostbite"), count * 2);
                
                if (frostbite > 2) {
                    await ctx.target.takeForceDamage(Math.floor(frostbite / 2));
                    await ctx.target.reduceStatus("Frostbite", frostbite);
                }
            });
        },
        (count) => {
            return `Clear up to ${Number(count) * 2} [/status/Frostbite] Frostbite from the target, and deal 1d8 Force Damage for every 2 cleared.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        "Chill Out",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let bind = Math.max(Math.floor(ctx.target.getStatusCount("Frostbite") / 2), 1);
                if (ctx.target.getStatusCount("Frostbite") > 3 + count) {
                    data.applyInfliction("Bind", Math.min(bind, count * 3), true);
                }
            });
        },
        (count) => {
            return `If the target has ${3 + count}+ [/status/Frostbite] Frostbite, apply [/status/Bind] Bind next round equal half of the target's [/status/Frostbite] Frostbite, up to ${Number(count) * 3}.`
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    //
    simpleStatusEffect("Bleed", false, true),
    simpleStatusEffect("Bleed", true, true, "Inflict Delayed Bleed"),
    markerEffect("Bleed+", false, 3),
    skillVigorEffect("Bleed", 2, 1),
    skillBonusEffect("Bleed", 2),
    statusPauseEffect("Hemorrhage", 5),
    new Effect(
        "Vampiric Gash",
        (context, count, trigger) => {
            context.flags.push("Vampiric Gash");
            context.events[trigger].push(async (ctx) => {
                let bleed = ctx.target.getStatusCount("Bleed");
                if (bleed > 0) {
                    let php = Number(ctx.actor.system.attributes.health.value);
                    await ctx.actor.heal(bleed, 0, 0, ctx.actor);
                    let hp = Number(ctx.actor.system.attributes.health.value);
                    createEffectsMessage(ctx.actor.name, `Heals ${bleed} HP from Vampiric Gash! (${php} -> ${hp})`);
                }
            });
        },
        (count) => {
            return `Heal HP equal to [/status/Bleed] Bleed on target. If the target did not clash, trigger their [/status/Bleed] Bleed.`
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        "Cauterize",
        (context, count, trigger) => {
            context.events[trigger].push(async (ctx) => {
                let bleed = Math.floor(ctx.target.getStatusCount("Bleed") / 2);
                if (bleed > 0) {
                    await ctx.target.applyStatus("Burn", bleed);
                    createEffectsMessage(ctx.actor.name, `Gains ${bleed} [/status/Burn] Burn from Cauterize!`);
                }
            });
        },
        (count) => {
            return `Inflict [/status/Burn] Burn equal to half of target's [/status/Bleed] Bleed.`
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    statusPauseEffect("Tendon Slice", 1),
    new Effect(
        "Trading Wounds",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let confirm = await pollUserInputConfirm(ctx.actor, `Apply Trading Wounds? (did you heal ${2 * count} HP?)`);

                if (confirm) {
                    data.applyInfliction("Bleed", count, false);
                }
            });
        },
        (count) => {
            return `If the user healed ${2 * count}+ HP during this action, inflict ${Number(count)} [/status/Bleed] Bleed.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        "Disgorge",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                if (ctx.target.getStatusCount("Bleed") > 0) {
                    let bleed = ctx.target.getStatusCount("Bleed");
                    let damage = Math.min(3 * count, bleed);

                    data.hpDamage += damage;
                }
            });
        },
        (count) => {
            return `If the target has [/status/Bleed] Bleed, deal ${Number(count) * 3} HP damage or HP damage equal to [/status/Bleed] Bleed, whichever is lower.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        "Red Plum Blossom",
        (context, count, trigger) => {
            context.triggers["On Crit"].applyInfliction("Bleed", count * 2, false);
        },
        (count) => {
            return `Inflict ${Number(count) * 2} [/status/Bleed] Bleed.`
        },
        ["On Crit"],
        false, 5, false, true
    ),
    //
    new Effect(
        `Gain Poise`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Poise", -count, false);
        },
        (count) => {
            return handleNegativeText(
                `Gain % [/status/Poise] Poise`,
                `Inflict % [/status/Poise] Poise`, 
            count);
        },
        ["Clash Win", "Clash Lose"],
    ),
    new Effect(
        `Poise Bonus`,
        (context, count, trigger) => {
            let req = count;
            if (context.actor.augmentEffectCount("Poise Bonus") > 0) {
                req += 3;
            }

            if (context.actor.getStatusCount("Poise") >= req) {
                context.dicePower = Number(context.dicePower) + count;
                context.skillDicePower = Number(context.skillDicePower) + count;
            }
        },
        (count) => {
            return `If the user has ${Number(count)}+ [/status/Poise] Poise, gain ${Number(count)} Dice Power. If your augment includes Poise Bonus, increase the requirement by 3.`
        },
        ["On Use"],
        false, 5
    ),
    new Effect(
        `Increase Critical`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Critical", -count, false);
        },
        (count) => {
            return `Gain ${Number(count)} [/status/Critical] Critical`;
        },
        ["Clash Win", "Clash Lose"], false
    ),
    markerEffect("Instant Crit", false, 1, "On Use", (count) => {
        return 'All [/status/Critical] Critical and [/status/Poise] Poise gain is resolved instantly.'
    }),
    markerEffect("Precision", 0, 1),
    markerEffect("Critical Conversion", 0, 1, ["On Use"], (count) => {
        return `If the character would exceed 10 [/status/Poise] Poise from this skill, set [/status/Poise] Poise to 1 and gain 1 [/status/Critical] Critical.`
    }),
    new Effect(
        `Poise Pause`,
        (context, count, trigger) => {
            context.events["On Use"].push(async (context) => {
                await context.actor.update({ "system.poisePaused": true }, { diff: false });
            })
        },
        (count) => {
            return "You do not roll for [/status/Critical] Critical Hits until the next round."
        },
        ["On Use"], false, 1, false, true
    ),
    markerEffect("Critical DMG+", false, 5, "On Crit", (count) => {
        return `Deal ${Number(count)*3} HP damage.`;
    }),
    new Effect(
        "Haste Crit",
        (context, count, trigger) => {
            context.events["Critical Hit"].push(async (ctx) => {
                await ctx.actor.applyStatus("Haste", count * 2);
                createEffectsMessage(ctx.actor.name, `Gains ${count * 2} [/status/Haste] Haste next round!`);
            });
        },
        (count) => {
            return `Gain ${Number(count) * 2} [/status/Haste] Haste next round.`
        },
        ["On Crit"],
        false, 5, false, true
    ),
    // - stance swap
    new Effect(
        "Scattering Dance",
        (context, count, trigger) => {
            context.events["Critical Hit"].push(async (ctx) => {
                await context.target.applyStatus("Hemorrhage", Math.min(Number(ctx.critical), count));
                createEffectsMessage(context.target.name, `Gains ${Math.min(Number(ctx.critical), count)} [/status/Hemorrhage] Hemorrhage from Scattering Dance!`)
            });
        },
        (count) => {
            return `Inflict [/status/Hemorrhage] Hemorrhage equal to [/status/Critical] Critical spent, max ${count}.`
        },
        ["On Crit"],
        false, 5, false, true
    ),
    new Effect(
        "Ink Over",
        (context, count, trigger) => {
            context.events["Critical Hit"].push(async (context) => {
                for (let i = 0; i < Math.min(context.critical, count); i++) {
                    await context.target.fireStatusEffect("Bleed");
                }
            })
        },
        (count) => {
            return `Trigger [/status/Bleed] Bleed for every [/status/Critical] Critical spent, max ${count} times.`
        },
        ["On Crit"], false, 5, false, true
    ),
    new Effect(
        `Elusive`,
        (context, count, trigger) => {
            context.flags.push("Elusive");
        },
        (count) => {
            return "Do not deal critical damage. Gain extra movement equal to half of the critical roll."
        },
        ["On Crit"], false, 5, false, true
    ),
    new Effect(
        `Bulwark Defense`,
        (context, count, trigger) => {
            context.flags.push("Bulwark Defense");
        },
        (count) => {
            return "Do not deal critical damage. Reduce damage taken by the critical roll."
        },
        ["On Crit"], false, 1, false, true
    ),
    new Effect(
        "Showdown",
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (ctx) => {
                let poise = ctx.target.getStatusCount("Poise");
                if (poise > 0) {
                    await ctx.target.setStatus("Poise", 0);
                    await ctx.actor.applyStatus("Poise", poise);
                    createEffectsMessage(ctx.actor.name, `Steals ${poise} [/status/Poise] Poise from the target!`);
                }
            });
        },
        (count) => {
            return `Steal the target's [/status/Poise] Poise.`
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    //
    simpleStatusEffect("Ruin", false, true),
    simpleStatusEffect("Devastation", false, true, "Increase Devastation"),
    markerEffect("Instant Devastation", false, 1, "On Use", (count) => {
        return 'All [/status/Devastation] Devastation and [/status/Ruin] Ruin infliction is resolved instantly.'
    }),
    markerEffect("Ruination"),
    markerEffect("Devastation Conversion", 0, 1, ["On Use"], (count) => {
        return `If the target would exceed 10 [/status/Ruin] Ruin from this skill, set [/status/Ruin] Ruin to 1 and apply 1 [/status/Devastation] Devastation.`
    }),
    new Effect(
        `Ruin Bonus`,
        (context, count, trigger) => {
            let req = Number(count);
            if (context.actor && context.actor.augmentEffectCount("Ruin Bonus") > 0) {
                req += 3;
            }

            if (context.target != null && context.target.getStatusCount("Ruin") >= req) {
                context.dicePower = Number(context.dicePower) + count;
                context.skillDicePower = Number(context.skillDicePower) + count;
            }
        },
        (count) => {
            return `If the target has ${count}+ [/status/Ruin] Ruin, gain ${Number(count)} Dice Power.`
        },
        ["On Use"],
        false,
        5
    ),
    new Effect(
        `Ruin Pause`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                await context.target.update({ "system.ruinPaused": true }, { diff: false });
            })
        },
        (count) => {
            return "Target does not roll for [/status/Devastation] Devastating Hits until the next round."
        },
        ["Clash Win"], false, 1, false, true
    ),
    markerEffect("Devastation DMG+", false, 5, "Devastating Hit", (count) => {
        return `Deal ${Number(count)*3} HP damage.`;
    }),
    new Effect(
        "Armor Decay",
        (context, count, trigger) => {
            context.triggers["Devastating Hit"].applyInfliction("Disarm", count, false);
            context.triggers["Devastating Hit"].applyInfliction("Fragile", count, false);
            context.triggers["Devastating Hit"].applyInfliction("Stagger_Fragile", count, false);
        },
        (count) => {
            return `Inflict ${Number(count)} [/status/Disarm] Disarm, [/status/Fragile] Fragile, and [/status/Stagger_Fraggile] Stagger Fragile.`
        },
        ["Devastating Hit"],
        false, 5, false
    ),
    new Effect(
        "[Type] Deterioration",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let type = await pollUserInputOptions(ctx.actor, "Choose [Type] Fragility to inflict.", [
                    {
                        name: "Slash Fragility",
                        icon: "/status/Slash_Fragility.png"
                    },
                    {
                        name: "Pierce Fragility",
                        icon: "/status/Pierce_Fragility.png"
                    },
                    {
                        name: "Blunt Fragility",
                        icon: "/status/Blunt_Fragility.png"
                    },
                ]);

                data.applyInfliction(type.replace(" ", "_"), 2 * count, true);
            });
        },
        (count) => {
            return `Apply ${Number(count) * 2} [Type] Fragility next round, chosen on application.`
        },
        ["Devastating Hit"],
        false, 5, false, true
    ),
    new Effect(
        `Devastating Force`,
        (context, count, trigger) => {
            context.events["Devastating Hit"].push(async (context) => {
                createEffectsMessage(context.target.name, `Is pushed ${Math.min(count, context.devastation)} SQR by Devastating Force!`);
                await requestForcedMovement(context.actor, context.target, context.target, Math.min(count, context.devastation), true, true);
            })
        },
        (count) => {
            return `Push the target a distance equal to [/status/Devastation] Devastation, max ${Number(count)}.`
        },
        ["Devastating Hit"], false, 5, false, true
    ),
    new Effect(
        "Devastating Shock",
        (context, count, trigger) => {
            context.triggers["Devastating Hit"].applyInfliction("Bind", count * 2, false);
        },
        (count) => {
            return `Inflict ${Number(count) * 2} [/status/Bind] Bind next round.`
        },
        ["Devastating Hit"],
        false, 5, false
    ),
    new Effect(
        "Debilitate",
        (context, count, trigger) => {
            context.triggers["Devastating Hit"].applyInfliction("Feeble", count, true);
            context.triggers["Devastating Hit"].applyInfliction("Disarm", count, true);
            context.triggers["Devastating Hit"].applyInfliction("Bind", count * 2, true);
        },
        (count) => {
            return `Inflict ${Number(count)} [/status/Feeble] Feeble, [/status/Disarm] Disarm, and ${Number(count) * 2} [/status/Bind] Bind next roun.`
        },
        ["Devastating Hit"],
        false, 5, false
    ),
    markerEffect("Primer", false, 1),
    //
    simpleStatusEffect("Rupture", true, true),
    markerEffect("Rupture+", false, 3),
    skillVigorEffect("Rupture", 2, 0, 2),
    skillBonusEffect("Rupture", 2, 0, 5, 2),
    markerEffect("Instant Rupture", false, 1, "On Use", (count) => {
        return 'All [/status/Rupture] Rupture infliction is resolved instantly.'
    }),
    new Effect(
        `Rupture Reversal`,
        (context, count, trigger) => {
            context.events["Rupture Burst"].push(async (context) => {
                let rupture = await context.target.getStatusCount("Rupture");
                if (rupture <= 0) return;
                rupture = Math.max(rupture, 16);
                
                let php = context.actor.system.attributes.health.value;
                await context.actor.heal(rupture, 0, 0);
                let hp = context.actor.system.attributes.health.value;
                createEffectsMessage(context.actor.name, `Healed ${rupture} HP from Rupture Reversal! (${php} -> ${hp})`);
            })
        },
        (count) => {
            return "Heal equal to [/status/Rupture] Rupture on target at time of burst (max 16)."
        },
        ["Rupture Burst"], false, 1, false, true
    ),
    new Effect(
        `Rupture Boost`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                context.forcedBurst.push("Rupture");
                let rupture = await context.target.getStatusCount("Rupture");
                if (rupture <= 3) return;

                await context.actor.takeDamageStatus(Math.floor(rupture / 2), "none", "HP", "Takes %DMG% HP damage from Rupture Boost! (%PHP% -> %HP%)");
                await context.target.takeDamageStatus(Math.floor(rupture / 2), "none", "HP", "Takes %DMG% HP damage from Rupture Boost! (%PHP% -> %HP%)");
            })
        },
        (count) => {
            return "Burst [/status/Rupture] Rupture. If the target has 4+ [/status/Rupture] Rupture, deal half of it as HP damage to target and self."
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        `Rupture Pause`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                context.forcedExcludeBurst.push("Rupture");
                let rupture = await context.target.getStatusCount("Rupture");
                if (rupture <= 0) return;

                await context.target.setStatus("Rupture", 0);
                await context.target.applyStatus("Rupture", 0, rupture);
                createEffectsMessage(context.target.name, `${rupture} active [/status/Rupture] Rupture moved to next round!`);
            })
        },
        (count) => {
            return "All [/status/Rupture] Rupture on target is moved to apply next round."
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        `Rupture Jag`,
        (context, count, trigger) => {
            context.triggers["Rupture Burst"].modify.push(async (context, data) => {
                let rupture = await context.target.getStatusCount("Rupture");
                if (rupture <= 0) return;
                rupture = Math.max(Math.floor(rupture / 2), count * 3);
                
                data.applyInfliction("Fragile", rupture, true);
            })
        },
        (count) => {
            return `Inflict [/status/Fragile] Fragile next round equal to half of burst [/status/Rupture] Rupture, max ${Number(count) * 3}.`
        }, 
        ["Rupture Burst"], false, 5, false, true
    ),
    new Effect(
        `Rupture Wounds`,
        (context, count, trigger) => {
            context.triggers["Rupture Burst"].applyInfliction("Bleed", 4, false);
        },
        (count) => {
            return `Inflict 4 [/status/Bleed] Bleed.`
        }, 
        ["Rupture Burst"], false, 1, false, false
    ),
    markerEffect("Rupture Shred", false, 1),
    new Effect(
        `Ruptured Omen`,
        (context, count, trigger) => {
            context.triggers["Rupture Burst"].modify.push(async (context, data) => {
                let rupture = await context.target.getStatusCount("Rupture");
                if (rupture <= 3) return;
                data.applyInfliction("Ruin", 1, false);
                data.applyInfliction("Devastation", 3, false);
            })
        },
        (count) => {
            return `If the target had 4+ [/status/Rupture] Rupture, inflict 1 [/status/Ruin] Ruin and 3 [/status/Devastation] Devastation.`
        }, 
        ["Rupture Burst"], false, 1, false, true
    ),
    //
    simpleStatusEffect("Tremor", true, true),
    markerEffect("Tremor+", false, 3),
    skillVigorEffect("Tremor", 3, 0, 1),
    skillBonusEffect("Tremor", 3, 5, 1),
    markerEffect("Instant Tremor", false, 1, "On Use", (count) => {
        return 'All [/status/Tremor] Tremor infliction is resolved instantly.'
    }),
    new Effect(
        `Tremor Reversal`,
        (context, count, trigger) => {
            context.events["Tremor Burst"].push(async (context) => {
                let tremor = await context.target.getStatusCount("Tremor");
                if (tremor <= 0) return;
                tremor = Math.max(tremor, 10);
                
                let pst = context.actor.system.attributes.stagger.value;
                await context.actor.heal(0, tremor, 0);
                let st = context.actor.system.attributes.stagger.value;
                createEffectsMessage(context.actor.name, `Healed ${tremor} ST from Tremor Reversal! (${pst} -> ${st})`);
            })
        },
        (count) => {
            return "Heal ST equal to [/status/Tremor] Tremor on target at time of burst (max 10)."
        },
        ["Tremor Burst"], false, 1, false, true
    ),
    new Effect(
        `Tremor Boost`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                context.forcedBurst.push("Tremor");
                let tremor = await context.target.getStatusCount("Tremor");
                if (tremor <= 3) return;

                await context.actor.takeDamageStatus(Math.floor(tremor / 2), "none", "ST", "Takes %DMG% ST damage from Tremor Boost! (%PST% -> %ST%)");
                await context.target.takeDamageStatus(Math.floor(tremor / 2), "none", "ST", "Takes %DMG% ST damage from Tremor Boost! (%PST% -> %ST%)");
            })
        },
        (count) => {
            return "Burst [/status/Tremor] Tremor. If the target has 4+ [/status/Tremor] Tremor, deal half of it as ST damage to target and self."
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        `Tremor Pause`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                context.forcedExcludeBurst.push("Tremor");
                let tremor = await context.target.getStatusCount("Tremor");
                if (tremor <= 0) return;

                await context.target.setStatus("Tremor", 0);
                await context.target.applyStatus("Tremor", 0, tremor);
                createEffectsMessage(context.target.name, `${tremor} active [/status/Tremor] Tremor moved to next round!`);
            })
        },
        (count) => {
            return "All [/status/Tremor] Tremor on target is moved to apply next round."
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        `Tremor Break`,
        (context, count, trigger) => {
            context.triggers["Tremor Burst"].modify.push(async (context, data) => {
                let tremor = await context.target.getStatusCount("Tremor");
                if (tremor <= 0) return;
                tremor = Math.max(Math.floor(tremor / 2), count * 3);
                
                data.applyInfliction("Stagger_Fragile", tremor, true);
            })
        },
        (count) => {
            return `Inflict [/status/Stagger_Fragile] Stagger Fragile next round equal to half of burst [/status/Tremor] Tremor, max ${Number(count) * 3}.`
        }, 
        ["Tremor Burst"], false, 5, false, true
    ),
    new Effect(
        `Tremor Shock`,
        (context, count, trigger) => {
            context.triggers["Tremor Burst"].modify.push(async (context, data) => {
                data.applyInfliction("Bind", 3, true);
            })
        },
        (count) => {
            return `Inflict 3 [/status/Bind] Bind next round.`
        }, 
        ["Tremor Burst"], false, 1, false, true
    ),
    new Effect(
        `Tremoring Nerves`,
        (context, count, trigger) => {
            context.triggers["Tremor Burst"].modify.push(async (context, data) => {
                data.applyInfliction("Feeble", 2, true);
                data.applyInfliction("Disarm", 2, true);
            })
        },
        (count) => {
            return `Target takes no ST damage from burst. Inflict 2 [/status/Feeble] Feeble and [/status/Disarm] Disarm next round.`
        }, 
        ["Tremor Burst"], false, 1, false, true
    ),
    new Effect(
        "Tremor Slam",
        (context, count, trigger) => {
            context.events["Tremor Burst"].push(async (ctx) => {
                let tremor = Math.min(ctx.target.getStatusCount("Tremor"), count * 2);
                
                if (tremor > 2) {
                    await createEffectsMessage(ctx.target.name, `Is pushed ${Math.floor(tremor / 2)} SQR away by Tremor Slam!`);
                    await requestForcedMovement(context.actor, context.target, context.target, Math.floor(tremor / 2), true, true);
                }
            });
        },
        (count) => {
            return `Push the target 1 SQR for every 2 [/status/Tremor] Tremor bursted, max ${Number(count)}.`
        },
        ["Tremor Burst"],
        false, 5, false, true
    ),
    new Effect(
        "Earthquake",
        (context, count, trigger) => {
            context.events["Tremor Burst"].push(async (ctx) => {
                let tremor = await ctx.target.getStatusCount("Tremor");
                if (tremor <= 0) return;

                let text = "";
                let targets = getCharactersWithinRadius(ctx.target, Number(count)).filter(x => x != ctx.actor);
                for (let target of targets) {
                    let option = await pollUserInputOptions(target, `Spend a reaction to try and block Earthquake?`, [
                        { name: "Take Unopposed" },
                        { name: "Block", icon: "/damageTypes/Block.png" },
                        { name: "Evade", icon: "/damageTypes/Evade.png" },
                    ]);

                    let blocked = false;

                    if (option == "Block") {
                        await target.spendReaction(false, false);
                        let bCtx = await target.outfit.getRollContextBlo(ctx.actor, false);
                        let roll = new Roll(`1d${bCtx.diceMax}+${bCtx.dicePower}`, "");
                        let result = await roll.evaluate();

                        if (result.total >= ctx.result) {
                            blocked = true;
                            text += `${target.name} blocks the Earthquake with a roll of ${result.total}!\n`;
                        }
                        else {
                            text += `${target.name} rolls ${result.total}, failing to block the Earthquake. Gains ${tremor} [/status/Tremor] Tremor and ${2 * count} [/status/Bind] Bind next round.\n`
                        }
                    } else if (option == "Evade") {
                        await target.spendReaction(false, false);
                        let eCtx = await target.outfit.getRollContextEvd(ctx.actor, false);
                        let roll = new Roll(`1d${eCtx.diceMax}+${eCtx.dicePower}`, "");
                        let result = await roll.evaluate();

                        if (result.total >= ctx.result) {
                            blocked = true;
                            text += `${target.name} evades the Earthquake with a roll of ${result.total}!\n`;
                        }
                        else {
                            text += `${target.name} rolls ${result.total}, failing to evade the Earthquake. Gains ${tremor} [/status/Tremor] Tremor and ${2 * count} [/status/Bind] Bind next round.\n`
                        }
                    }
                    else {
                        text += `${target.name} gains ${tremor} [/status/Tremor] Tremor and ${2 * count} [/status/Bind] Bind next round.\n`;
                    }

                    if (!blocked) {
                        await target.applyStatus("Tremor", 0, tremor);
                        await target.applyStatus("Bind", 0, 2 * count);
                    }
                }

                text += `${ctx.target.name} gains ${2 * count} [/status/Bind] Bind next round.`

                await ctx.target.applyStatus("Bind", 0, 2 * count);

                createEffectsMessage(ctx.actor.name, text);
            });
        },
        (count) => {
            return `Apply the target's [/status/Tremor] Tremor to characters within ${Number(count)} SQR. Affected targets receive [/status/Bind] Bind equal to double the target's [/status/Tremor] Tremor next round. Can be blocked.`
        },
        ["Tremor Burst"],
        false, 5, false, true
    ),
    //
    simpleStatusEffect("Sinking", true, true),
    markerEffect("Sinking+", false, 3),
    skillVigorEffect("Sinking", 3, 0, 1),
    skillBonusEffect("Sinking", 3, 5, 1),
    markerEffect("Instant Sinking", false, 1, "On Use", (count) => {
        return 'All [/status/Sinking] Sinking infliction is resolved instantly.'
    }),
    new Effect(
        `Sinking Pause`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                context.forcedExcludeBurst.push("Sinking");
                let sinking = await context.target.getStatusCount("Sinking");
                if (sinking <= 0) return;

                await context.target.setStatus("Sinking", 0);
                await context.target.applyStatus("Sinking", 0, sinking);
                createEffectsMessage(context.target.name, `${sinking} active [/status/Sinking] Sinking moved to next round!`);
            })
        },
        (count) => {
            return "All [/status/Sinking] Sinking on target is moved to apply next round."
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        `Sinking Deluge`,
        (context, count, trigger) => {
            context.events["Sinking Burst"].push(async (context) => {
                let sinking = await context.target.getStatusCount("Sinking");
                if (sinking <= 0) return;

                await context.target.takeDamageStatus(Math.floor(context.target.system.staggered || context.target.system.attributes.sanity.value <= 0 ? sinking * 2 : sinking * 1.5),
                "none", "HP", "Takes %DMG% HP damage from [/status/Sinking] Sinking Deluge! (%PHP% -> %HP%)");
            })
        },
        (count) => {
            return "Deal HP damage equal to 1.5x burst [/status/Sinking] Sinking. If the target is staggered or in panic, deal 2x instead."
        },
        ["Sinking Burst"], false, 1, false, true
    ),
    new Effect(
        `Broken Heart`,
        (context, count, trigger) => {
            context.triggers["Sinking Burst"].modify.push(async (context, data) => {
                let sinking = await context.target.getStatusCount("Sinking");
                if (sinking < 2) return;

                data.applyInfliction("Paralysis", Math.min(Math.floor(sinking / 2), count), true);
            })
        },
        (count) => {
            return `Inflict [/status/Paralysis] Paralysis next round equal to half of burst [/status/Sinking] Sinking, max ${Number(count)}`
        },
        ["Sinking Burst"], false, 5, false, true
    ),
    new Effect(
        `Suffocated Will`,
        (context, count, trigger) => {
            context.triggers["Sinking Burst"].modify.push(async (context, data) => {
                let sinking = await context.target.getStatusCount("Sinking");
                if (sinking <= 0) return;

                data.applyInfliction("Smoke", Math.min(sinking, count * 2), false);
            })
        },
        (count) => {
            return `Inflict [/status/Smoke] Smoke next round equal to burst [/status/Sinking] Sinking, max ${Number(count) * 2}`
        },
        ["Sinking Burst"], false, 5, false, true
    ),
    new Effect(
        `Spine Chill`,
        (context, count, trigger) => {
            context.triggers["Sinking Burst"].modify.push(async (context, data) => {
                let sinking = await context.target.getStatusCount("Sinking");
                if (sinking <= 0) return;

                data.applyInfliction("Frostbite", Math.min(sinking, count * 2), false);
            })
        },
        (count) => {
            return `Inflict [/status/Frostbite] Frostbite next round equal to burst [/status/Sinking] Sinking, max ${Number(count) * 2}`
        },
        ["Sinking Burst"], false, 5, false, true
    ),
    new Effect(
        `Absorb Sinking`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                let sinking = await context.target.getStatusCount("Sinking");
                if (sinking <= 0) return;

                let gain = Math.min(Math.floor(sinking / 2), count);

                if (gain > 0) {
                    await context.actor.applyStatus("Strength", 0, gain);
                    await context.actor.applyStatus("Endurance", 0, gain);
                }

                await context.target.setStatus("Sinking", 0);
                await context.actor.setStatusNext("Sinking", sinking);

                createEffectsMessage(context.actor.name, `Absorbs ${sinking} [/status/Sinking] Sinking from target${gain > 0 ? ` gaining ${gain} [/status/Strength] Strength and [/status/Endurance] Endurance` : ""}!`);
            })
        },
        (count) => {
            return `Transfer all [/status/Sinking] Sinking from target to self. Gain 1 [/status/Strength] Strength and [/status/Endurance] Endurance next round for every 2 absorbed, max ${Number(count)}.`
        },
        ["Clash Win"], false, 5, false, true
    ),
    new Effect(
        `Transfer Sinking`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                let sinking = Math.min(await context.actor.getStatusCount("Sinking"), count);
                if (sinking <= 0) return;

                await context.actor.reduceStatus("Sinking", sinking);
                await context.target.applyStatus("Sinking", 0, sinking);

                createEffectsMessage(context.actor.name, `Transfers ${sinking} [/status/Sinking] Sinking to the target!`);
            })
        },
        (count) => {
            return `Transfer up to ${Number(count)} [/status/Sinking] Sinking from self to target, applying next round.`
        },
        ["Clash Win"], false, 5, false, true
    ),
    markerEffect("Lowered Guard", false, 5, "Clash Lose", (count) => {
        return `When at ${Number(count)}+ [/status/Sinking] Sinking, gain ${Number(count) * 2} [/status/Protection] Protection and [/status/Stagger_Protection] Stagger Protection before taking damage.`
    }),
    //
    simpleStatusEffect("Smoke", false, true),
    new Effect(
        `Smoke Overflow`,
        (context, count, trigger) => {
            if (context.actor != null) {
                let stacks = context.actor.getStatusCount("Smoke");
                let req = (2 * count) + (2 * context.actor.augmentEffectCount(`Smoke Overflow`));

                if (stacks >= req) {
                    context.dicePower = Number(context.dicePower) + count;
                    context.skillDicePower = Number(context.skillDicePower) + count;
                }
            }
        },
        (count) => {
            return `Gain ${Number(count)} Dice Power if the user has ${2 * count}+ [/status/Smoke] Smoke. Increase requirement by 2 for every count of Smoke Overflow on augment..`
        },
        ["On Use"],
        false,
        5
    ),
    skillBonusEffect("Smoke", 3, 5, 1),
    markerEffect("Fumigate", false, 1, "Clash Win", (count) => {
        return "Consume all [/status/Smoke] Smoke to deal HP damage equal to [/status/Smoke] Smoke consumed."
    }),
    new Effect(
        `Inhale Smoke`,
        (context, count, trigger) => {
            context.events[`${trigger} Instant`].push(async (context) => {
                let smoke = await context.target.getStatusCount("Smoke");
                if (smoke <= 0) return;

                await context.target.setStatus("Smoke", 0);
                await context.actor.setStatusNext("Smoke", smoke);

                createEffectsMessage(context.actor.name, `Absorbs ${smoke} [/status/Smoke] Smoke from target!`);
            })
        },
        (count) => {
            return `Transfer all [/status/Smoke] Smoke from target to self.`
        },
        ["Clash Win", "Clash Lose"], false, 1, false, true
    ),
    new Effect(
        `Exhale Smoke`,
        (context, count, trigger) => {
            context.events[`${trigger} Instant`].push(async (context) => {
                let smoke = Math.min(await context.actor.getStatusCount("Smoke"), count);
                if (context.hasEffect("Gauged Release")) {
                    smoke = await pollUserInputText(context.actor, `Gauged Release: Smoke to spend on Exhale (max ${smoke})`, 0, "number", smoke, 1);
                }
                
                if (smoke <= 0) return;

                await context.actor.reduceStatus("Smoke", smoke);
                await context.target.applyStatus("Smoke", 0, smoke);

                createEffectsMessage(context.actor.name, `Transfers ${smoke} [/status/Smoke] Smoke to the target!`);
            })
        },
        (count) => {
            return `Transfer all [/status/Smoke] Smoke from self to target.`
        },
        ["Clash Win", "Clash Lose"], false, 1, false, true
    ),
    markerEffect("Smoke Stack", false, 1),
    new Effect(
        `Evaporate`,
        (context, count, trigger) => {
            context.events[`${trigger}`].push(async (context) => {
                let count = await context.actor.performReduceStatus("Evaporate", context.actor.getReduceStatusCount());

                if (count >= 2) {
                    let smoke = Math.floor(count / 2);
                    smoke = Math.min(smoke, 3 * count);

                    await context.actor.applyStatus("Smoke", smoke, 0);
                    createEffectsMessage(context.actor.name, `Gained ${smoke} [/status/Smoke] Smoke from Evaporate!`)
                }
            })
        },
        (count) => {
            return `Perform Reduce Status and gain half of what is reduced as [/status/Smoke] Smoke, max ${3 * count}.`
        },
        ["Clash Win", "Clash Lose"], false, 1, false, true
    ),
    smokeStatusEffect("Burn", 2, false, 1),
    smokeStatusEffect("Bleed", 2, false, 1),
    smokeStatusEffect("Frostbite", 2, false, 1),
    smokeStatusEffectSelf("Poise", 2, false, 1),
    smokeStatusEffect("Ruin", 2, false, 1),
    smokeStatusEffect("Paralysis", 1, true, 1),
    smokeStatusEffectSelf("Strength", 1, true, 3),
    smokeStatusEffectSelf("Endurance", 1, true, 3),
    smokeStatusEffect("Feeble", 1, true, 3),
    smokeStatusEffect("Disarm", 1, true, 3),
    //
    markerEffect("Instant Haste", false, 1, "On Use", (count) => {
        return 'All [/status/Haste] Haste gain is resolved instantly.'
    }),
    new Effect(
        `Circle Throw`,
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                if (context.actor.getStatusCount("Haste") >= count) {
                    createEffectsMessage(context.target.name, `Is pushed ${count} SQR by Circle Throw!`);
                    await requestForcedMovement(context.actor, context.target, context.target, count, false, true);
                }
            })
        },
        (count) => {
            return `If at or above ${Number(count)} [/status/Haste] Haste, push the target ${Number(count)} SQR in any direction.`
        },
        ["Clash Win"], false, 5, false, true
    ),
    new Effect(
        `Follow Through`,
        (context, count, trigger) => {
            context.conditionals.push(new Conditional(
                "Follow Through", `When moving ${Number(count) * 2} SQR before the attack, deal ${Number(count)}d8 Force Damage`,
                (context) => {
                    context.flags.push("Follow Through");
                },
                [], null
            ));

            context.events["Clash Win"].push(async (context) => {
                if (context.actor.getStatusCount("Haste") >= count * 2 && context.flags.includes("Follow Through")) {
                    await context.target.takeForceDamage(count, context);
                }
            });
        },
        (count) => {
            return `If at or above ${Number(count)} [/status/Haste] Haste and moved ${Number(count) * 2} SQR towards the target, deal ${Number(count)}d8 Force Damage.`
        },
        ["Clash Win"], false, 5, false, true
    ),
    new Effect(
        `Blitz`,
        (context, count, trigger) => {
            if (context.actor.getStatusCount("Haste") >= count * 2) {
                context.dicePower = Number(context.dicePower) - 2;
                context.skillDicePower = Number(context.skillDicePower) - 2;
            }
        },
        (count) => {
            return `If at or above ${Number(count) * 2} [/status/Haste] Haste, replace attack with ${Number(count)} attacks with -2 Dice Power.`
        },
        ["On Use"], false, 2, false, false
    ),
    new Effect(
        `Overspeed`,
        (context, count, trigger) => {
            if (context.actor.getStatusCount("Haste") >= count * 2) {
                context.dicePower = Number(context.dicePower) - 2;
                context.skillDicePower = Number(context.skillDicePower) - 2;
            }
        },
        (count) => {
            return `Attack becomes a piercing line up to [/status/Haste] Haste SQR, with -2 Dice Power.`
        },
        ["On Use"], false, 1, false, false
    ),
    //
    healEffect(2, "HP"),
    healEffect(1, "ST"),
    healEffect(1, "SP"),
    simpleStatusEffectSelf("Strength", 1, "Feeble"),
    simpleStatusEffectSelf("Endurance", 1, "Disarm"),
    simpleStatusEffectSelf("Haste", 1, "Bind"),
    simpleStatusEffectSelf("Protection", 1),
    simpleStatusEffectSelf("Stagger Protection", 1),
    allyStatusEffect("Protection", 2, true),
    allyStatusEffect("Stagger Protection", 2, true),
    allyStatusEffect("[Type] Protection", 2, true),
    allyStatusEffect("Strength", 1, true),
    allyStatusEffect("Endurance", 1, true),
    allyStatusEffect("Haste", 1, true),
    allyStatusEffect("Poise", 1, false),
    allyStatusEffect("Critical", 1, false),
    new Effect(
        "[Type] Protection",
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let type = await pollUserInputOptions(ctx.actor, "Choose [Type] Protection to gain.", [
                    {
                        name: "Slash Protection",
                        icon: "/status/Slash_Protection.png"
                    },
                    {
                        name: "Pierce Protection",
                        icon: "/status/Pierce_Protection.png"
                    },
                    {
                        name: "Blunt Protection",
                        icon: "/status/Blunt_Protection.png"
                    },
                ]);
                data.applyInfliction(type.replace(" ", "_"), -count, true);
            });
        },
        (count) => {
            return `Gain ${Number(count)} [Type] Protection next round, chosen on application.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    ),
    //
    markEffect("Tire them Out",
        (data, count) => {
            data.applyInfliction("Stagger_Fragile", 3 * count, true);
        },
        count => `apply ${Number(count) * 3} [/status/Stagger_Fragile] Stagger Fragile next round`,
    ),
    markEffect("Finish them Off",
        (data, count) => {
            data.applyInfliction("Fragile", 3 * count, true);
        },
        count => `apply ${Number(count) * 3} [/status/Fragile] Fragile next round`,
    ),
    markEffect("Ignite the Wound",
        (data, count) => {
            data.applyInfliction("Burn", count, false);
            data.applyInfliction("Bleed", count, false);
        },
        count => `apply ${Number(count)} [/status/Burn] Burn and [/status/Bleed] Bleed`,
    ),
    markEffect("Hammer the Gap",
        (data, count) => {
            data.applyInfliction("Rupture", count * 2, true);
            data.applyInfliction("Tremor", count, true);
        },
        count => `apply ${Number(count) * 2} [/status/Rupture] Rupture and ${Number(count)} [/status/Tremor] Tremornext round`,
    ),
    markEffect("Make them Cry",
        (data, count) => {
            data.applyInfliction("Sinking", count, false);
            data.applyInfliction("Smoke", count, false);
        },
        count => `apply ${Number(count)} [/status/Sinking] Sinking and [/status/Smoke] Smoke`,
    ),
    markEffect("Freeze in Place",
        (data, count) => {
            data.applyInfliction("Frostbite", count, false);
            data.applyInfliction("Bind", count, true);
        },
        count => `apply ${Number(count)} [/status/Frostbite] Frostbite and [/status/Bind] Bind`,
    ),
    markEffect("Sense their Weakness",
        (data, count) => {
            data.applyInfliction("Ruin", count, false);
            data.applyInfliction("Poise", -count, false);
        },
        count => `apply ${Number(count)} [/status/Ruin] Ruin and gain ${Number(count)} [/status/Poise] Poise`,
    ),
    markEffect("Exploit the Opportunity",
        (data, count) => {
            data.applyInfliction("Devastation", count, false);
            data.applyInfliction("Critical", -count, false);
        },
        count => `apply ${Number(count)} [/status/Devastation] Devastation and gain ${Number(count)} [/status/Critical] Critical`,
    ),
    markEffect("Weaken your Quarry",
        (data, count) => {
            data.applyInfliction("Feeble", count, true);
            data.applyInfliction("Disarm", count, true);
        },
        count => `apply ${Number(count)} [/status/Feeble] Feeble and [/status/Disarm] Disarm next round`,
    ),
    markEffect("Capture Them",
        (data, count) => {
            data.applyInfliction("Bind", count * 2, true);
            data.applyInfliction("Paralysis", count, true);
        },
        count => `apply ${Number(count) * 2} [/status/Bind] Bind and ${Number(count)} [/status/Paralysis] Paralysis next round`,
    ),
    markEffect("Grounding Cycle",
        (data, count) => {
            data.applyInfliction("Charge", (Number(count) * -3), false);
        },
        count => `gain ${Number(count) * 3} [/status/Charge] Charge. [/status/Charge] Charge does not decay at end of round.`,
    ),
    markEffect("Assist Attack",
        (data, count) => {
            
        },
        count => `allow an ally in attack range to spend a reaction to attack the target.`,
    ),
    //
    new Effect(
        "Ignore Infliction",
        (context, count, trigger) => {
            context.events[`${trigger} Instant`].push(async (context) => {
                context.flags.push("IgnoreInfliction");
            });
        },
        (count) => {
            return `Ignore target's status inflictions.`
        },
        ["Clash Win", "Clash Lose"], false, 1, false, true
    ),
    new Effect(
        `Shooting Star`,
        (context, count, trigger) => {
            context.dicePower = Number(context.dicePower) - 1;
            context.skillDicePower = Number(context.skillDicePower) - 1;
        },
        (count) => {
            return `Replace attack with a piercing line attack with -1 Dice Power.`
        },
        ["On Use"], false, 1, false, false
    ),
    new Effect(
        `Multi-Hit`,
        (context, count, trigger) => {
            context.dicePower = Number(context.dicePower) - 2;
            context.skillDicePower = Number(context.skillDicePower) - 2;
            context.diceCount = Math.min(Number(context.diceCount) + count, 3);
        },
        (count) => {
            return `Replace attack with ${1 + Number(count)} attacks with -2 Dice Power each.`
        },
        ["On Use"], false, 2, false, false
    ),
    //
    new Effect(
        "Gain Charge",
        (context, count, trigger) => {
            if (count < 0) {
                context.costs.push({
                    cost: Math.abs(count),
                    status: "Charge"
                })
            }
            else {
                context.triggers["On Use"].applyInfliction("Charge", -count);
            }
        },
        (count) => {
            return count < 0 ? `Spend ${Math.abs(count)} [/status/Charge] Charge` : `Gain ${Number(count)} [/status/Charge] Charge`;
        },
        ["On Use"],
        true,
        6
    ),
    chargeEffect("Charge - Dice Power Up", 6,
        (context, count, trigger) => {
            context.dicePower = Number(context.dicePower) + Number(count);
            context.skillDicePower = Number(context.skillDicePower) + Number(count);
        },
        count => `increase Dice Power by ${Number(count)}`, ["On Use"]
    ),
    chargeEffect("Charge - Dice Max Up", 3,
        (context, count, trigger) => {
            context.diceMax = Number(context.diceMax) + count;
        },
        count => `increase Dice Max by ${Number(count)}`, ["On Use"]
    ),
    chargeEffect("Charge - Regen HP", 2,
        (context, count, trigger) => {
            context.triggers[trigger].hpHeal = Number(context.triggers[trigger].hpHeal) + (count * 3);
        },
        count => `recover ${Number(count) * 3} HP`
    ),
    chargeEffect("Charge - Regen ST", 2,
        (context, count, trigger) => {
            context.triggers[trigger].stHeal = Number(context.triggers[trigger].stHeal) + (count * 2);
        },
        count => `recover ${Number(count) * 2} ST`
    ),
    chargeEffect("Charge - Regen SP", 2,
        (context, count, trigger) => {
            context.triggers[trigger].spHeal = Number(context.triggers[trigger].spHeal) + (count * 2);
        },
        count => `recover ${Number(count) * 2} SP`
    ),
    //
    chargeInflictStatus("Burn", 2),
    chargeInflictStatus("Frostbite", 2),
    chargeInflictStatus("Bleed", 2),
    chargeInflictStatus("Smoke", 2),
    chargeInflictStatus("Rupture", 1, true),
    chargeInflictStatus("Tremor", 2, true),
    chargeInflictStatus("Sinking", 3, true),
    chargeInflictStatus("Ruin", 2),
    chargeInflictStatus("Paralysis", 4, true),
    chargeInflictStatus("Feeble", 6, true),
    chargeInflictStatus("Bind", 3, true),
    chargeInflictStatus("Disarm", 6, true),
    chargeInflictStatus("Fragile", 3, true),
    chargeInflictStatus("Stagger_Fragile", 4, true),
    //
    chargeAllyStatusEffect("Poise", 2, 1, false),
    chargeAllyStatusEffect("Strength", 6, 1, true),
    chargeAllyStatusEffect("Endurance", 6, 1, true),
    chargeAllyStatusEffect("Haste", 3, 1, true),
    chargeAllyStatusEffect("Protection", 2, 2, true),
    chargeAllyStatusEffect("Stagger Protection", 2, 2, true),
    chargeAllyStatusEffect("[Type] Protection", 2, 2, true),
    chargeAllyStatusEffect("Charge Barrier", 2, 1, true),
    //
    chargeEffect("Charge - Multihit", 6,
        (context, count, trigger) => {
            context.dicePower = Number(context.dicePower) - 2;
            context.skillDicePower = Number(context.skillDicePower) - 2;
            context.diceCount = Math.min(Number(context.diceCount) + count, 3);
        },
        count => `replace attack with ${Number(count)} attacks with -2 Dice Power each`
    , ["On Use"], 2),
    chargeEffect("Charge - Shooting Star", 6,
        (context, count, trigger) => {
            context.dicePower = Number(context.dicePower) - 1;
            context.skillDicePower = Number(context.skillDicePower) - 1;
        },
        count => `replace attack with a piercing line with -1 Dice Power`
    , ["On Use"], 1),
    //
    new Effect(
        "Charge - Maintained Barrier",
        (context, count, trigger) => {
            context.events[`${trigger}`].push(async (context) => {
                await context.actor.setMaintainedBarrier(true);
            });
        },
        (count) => {
            return `[/status/Charge_Barrier] Charge Barrier only decays by half at end of round.`
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        "Charge - Repellent Barrier",
        (context, count, trigger) => {
            context.events[`${trigger}`].push(async (context) => {
                let barrier = await context.getStatusCount("Charge_Barrier");

                if (barrier > 0) {
                    createEffectsMessage(context.actor.name, `Pushes the target ${Math.min(barrier, count)} SQR from Repellent Barrier!`);
                }
            });
        },
        (count) => {
            return `Push the target a distance equal to [/status/Charge_Barrier] Charge Barrier on self, max ${Number(count)} SQR.`
        },
        ["Clash Win", "Clash Lose"], false, 5, false, true
    ),
    new Effect(
        `Charge - Seismic Generator`,
        (context, count, trigger) => {
            context.triggers["Tremor Burst"].modify.push(async (context, data) => {
                let tremor = await context.target.getStatusCount("Tremor");
                if (tremor <= 0) return;
                tremor = Math.max(tremor, 12);
                
                data.applyInfliction("Charge", -tremor, true);
            })
        },
        (count) => {
            return `Gain [/status/Charge] Charge equal to burst [/status/Tremor] Tremor, max 12`
        }, 
        ["Tremor Burst"], false, 1, false, true
    ),
    new Effect(
        `Charge - Rupturing Generator`,
        (context, count, trigger) => {
            context.triggers["Rupture Burst"].modify.push(async (context, data) => {
                let rupture = await context.target.getStatusCount("Rupture");
                if (rupture <= 0) return;
                rupture = Math.max(rupture, 12);
                
                data.applyInfliction("Charge", -rupture, true);
            })
        },
        (count) => {
            return `Gain [/status/Charge] Charge equal to burst [/status/Rupture] Rupture, max 12`
        }, 
        ["Rupture Burst"], false, 1, false, true
    ),
    //
    overchargeEffectEvent("Overcharge - Refraction Strike", 1,
        (context, count, trigger) => {
            if (context.actor && !context.flags.includes("Refraction Strike")) {
                let reactions = context.actor.system.reactions;
                context.dicePower = Number(context.dicePower) + Math.clamp(reactions, 1, 6);
                context.skillDicePower = Number(context.skillDicePower) + Math.clamp(reactions, 1, 6);
            }

            context.events["On Use"].push(async (context) => {
                await context.actor.update({ "system.reactions": 0 }, { diff: false });
                createEffectsMessage(context.actor.name, `${context.actor.name} burns all of their reactions to empower the attack!`);
            });
        },
        count => `forfeit all reactions and increase Dice Power by the amount forfeit, max 6`,
        ["On Use"], 1
    ),
    overchargeEffectEvent("Overcharge - Charge Release", 1,
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.actor.takeForceDamage(count, context);
                await requestForcedMovement(context.actor, context.target, context.target, count * 2, false, true);
            });
        },
        count => `deal ${Number(count)}d8 Force Damage and push target up to ${Number(count) * 2} SQR`,
        ["Clash Win"], 3, false
    ),
    overchargeEffectEvent("Overcharge - Loaded Branding", 2,
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.actor.handleLoadedBranding(context.target);
            });
        },
        count => `mark the target with ANY mark type.`,
        ["Clash Win", "Clash Lose"], 1, false
    ),
    overchargeEffectEvent("Overcharge - Reflective Barrier", 3,
        (context, count, trigger) => {
            context.events[`${trigger} Instant`].push(async (context) => {
                context.flags.push("Reflective Barrier");
            });
        },
        count => `reflect the target's status inflictions back to them`,
        ["Clash Win", "Clash Lose"], 1, false
    ),
    overchargeEffectEvent("Overcharge - Charge Byproducts", 1,
        (context, count, trigger) => {
            
        },
        count => `create up to ${Number(count) * 2} hazards in adjacent tiles`,
        ["Clash Win", "Clash Lose"], 5, true
    ),
    overchargeEffect("Overcharge - Adaptive Shot", 2,
        (context, count, trigger) => {
            context.dicePower = Number(context.dicePower) - 1;
            context.skillDicePower = Number(context.skillDicePower) - 1;
        },
        count => `replace attack with a piercing line with -1 Dice Power. The line may redirect up to two times when hitting a target.`,
        ["On Use"], 1, false
    ),
    overchargeEffect("Overcharge - Rip Space", 4,
        (context, count, trigger) => {
            if (!context.flags.includes("Rip Space")) {
                context.flags.push("Rip Space");
                context.dicePower = Number(context.dicePower) + 2;
                context.skillDicePower = Number(context.skillDicePower) + 2;
            }

            context.events["Before Attack"].push(async (context) => {
                let distance = await requestForcedMovement(context.actor, context.actor, context.target, 1, false, false, true);
                let damage = Math.min(distance * 2, Math.max(context.actor.system.attributes.stagger.value - 1, 0));
                if (distance != -1) {
                    await context.actor.takeDamageStatus(damage, "", "ST", `Takes %DMG% ST damage from ripping through space! (%PST% -> %ST%)`);
                    context.bonusAttackDamage = Number(context.bonusAttackDamage) + distance * 2;
                }
            });
        },
        count => `gain +2 Dice Power and cause all damage dealt by this attack to strike Weak (1.5x), unless the target is already Fatal (2x). Before attack, rip through space to an unoccupied tile adjacent to the target. For every SQR ripped through, take 2 ST damage and increase the attack damage by +2 (cannot stagger self).`,
        ["On Use"], 1, false
    ),
    overchargeEffectEvent("Overcharge - Replicating Shell", 1,
        (context, count, trigger) => {
            context.events[`${trigger}`].push(async (context) => {
                let total = 0;
                applyInAoe(context.actor, 3, async (actor) => {
                    total++;
                    if (total <= count) {
                        await actor.applyStatus("Charge_Barrier", 0, 5);
                    }
                }, context.actor);
            });
        },
        count => `apply 5 [/status/Charge_Barrier] Charge Barrier next round to up to ${Number(count)} allies within 3 SQR`,
        ["Clash Win", "Clash Lose"], 5, true
    ),
    overchargeEffectEvent("Overcharge - Vulnerability", 4,
        (context, count, trigger) => {
            context.events[`${trigger} Instant`].push(async (context) => {
                context.flags.push("OC Vuln");
            });
        },
        count => `double all status inflictions.`,
        ["Clash Win"], 1, false
    ),
    new Effect(
        `Overcharge - Reenergize`,
        (context, count, trigger) => {
            context.events[`${trigger}`].push(async (context) => {
                let count = await pollUserInputText(context.actor, "Choose [/status/Overcharge] Overcharge count to spend.", 0, "number", context.actor.getStatusCount("Overcharge"), 0);

                if (count > 0) {
                    await context.actor.reduceStatus("Overcharge", count);
                    await context.actor.applyStatus("Charge", count * 8);
                    createEffectsMessage(context.actor.name, `Spends ${count} [/status/Overcharge] Overcharge to gain ${count * 8} [/status/Charge] Charge!`)
                }
            })
        },
        (count) => {
            return `Convert any amount of [/status/Overcharge] Overcharge into 8x as much [/status/Charge] Charge.`
        },
        ["On Use"], false, 1, false, true
    ),
    // dummy effects
    markerEffect("Target Shift", false, 1, "Clash Win", c => `Transfer your Mark to another target.`),
    //
    new Effect(
        'Consume Bloodfeast',
        (context, count, trigger) => {
            context.costs.push({
                cost: count,
                status: "Bloodfeast",
            });
        },
        (count) => {
            return `Consume ${count} [/status/Bloodfeast] Bloodfeast.`
        },
        ["On Use"],
        false, 9999
    ),
    new Effect(
        'Heal HP',
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let team = findActorsOfTeam(context.actor);
                let options = [];
                let map = [];

                for (let member of team) {
                    options.push({ name: member.system.id, displayName: member.name });
                    map[member.system.id] = member;
                }

                let target = await pollUserInputOptions(context.actor, "Choose ally to heal.", options);
                target = map[target];
                let php = target.system.attributes.health.value;
                await target.heal(4 * count, 0, 0, context.actor);
                let hp = target.system.attributes.health.value;
                createEffectsMessage(context.actor.name, `Restores ${4 * count} HP to ${target.name}! (${php} -> ${hp})`);
            });
        },
        (count) => {
            return `Restore ${4 * count} HP to an ally.`;
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    ),
    new Effect(
        'Piercing Blood',
        (context, count, trigger) => {
            let consumed = Math.floor(context.actor.getSpentBloodfeast() / 10);
            if (consumed > 0) {
                context.triggers[trigger].applyInfliction("Bleed", consumed, false);
            }
        },
        (count) => {
            return `Inflict 1 [/status/Bleed] Bleed for every 10 [/status/Consumed_Bloodfeast] Consumed Bloodfeast.`
        }
    ),
    new Effect(
        'Hardblood - Haste',
        (context, count, trigger) => {
            context.costs.push({
                cost: count * 15,
                status: "Bloodfeast",
            });

            context.triggers[trigger].applyInfliction("Haste", count, true);
        },
        (count) => {
            return `Consume ${count * 15} [/status/Bloodfeast] Bloodfeast to gain ${count} [/status/Haste] Haste next round.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5
    ),
    new Effect(
        'Spit Blood',
        (context, count, trigger) => {
            context.costs.push({
                cost: count * 5,
                status: "Consumed_Bloodfeast",
            });

            context.dicePower = Number(context.dicePower) + count;
            context.skillDicePower = Number(context.skillDicePower) + count;
        },
        (count) => {
            return `Consume ${count * 5} [/status/Consumed_Bloodfeast] Consumed Bloodfeast to gain ${count} Dice Power.`
        },
        ["On Use"],
        false, 5
    ),
    new Effect(
        'Chains of Others',
        (context, count, trigger) => {
            context.costs.push({
                cost: count * 10,
                status: "Bloodfeast",
            });

            context.triggers[trigger].applyInfliction("Bind", count, true);
        },
        (count) => {
            return `Consume ${count * 10} [/status/Bloodfeast] Bloodfeast to inflict ${count} [/status/Bind] Bind next round.`
        },
        ["Clash Win"],
        false, 5
    ),
    new Effect(
        'Bloody Whirlpool',
        (context, count, trigger) => {
            context.costs.push({
                cost: count * 8,
                status: "Bloodfeast",
            });

            context.events[trigger].push(async (context) => {
                let targets = getAlliesWithinRadius(context.actor, count + 1).concat(getEnemiesWithinRadius(context.actor, count + 1));

                for (let target of targets) {

                }
            });
        },
        (count) => {
            return `Consume ${count * 8} [/status/Bloodfeast] Bloodfeast to pull all characters within ${count + 1} SQR towards you by ${count} SQR.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        `Blood-Tinged Blade`,
        (context, count, trigger) => {
            context.costs.push({
                cost: 10,
                status: "Bloodfeast",
            });
        },
        (count) => {
            return `Spend 10 [/status/Bloodfeast] Bloodfeast to attack another target with this weapon. This extra attack may not use skills.`;
        },
        ["Clash Win"],
        false, 1, false, true
    ),
    new Effect(
        "Steal Sustenance",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let bloodfeast = Math.min(count * 5, context.target.getStatusCount("Consumed_Bloodfeast"));
                
                if (bloodfeast > 0) {
                    await context.target.reduceStatus("Consumed_Bloodfeast", bloodfeast);
                    await context.actor.applyStatus("Consumed_Bloodfeast", bloodfeast);

                    createEffectsMessage(context.actor.name, `Steals ${bloodfeast} [/status/Consumed_Bloodfeast] Consumed Bloodfeast from the target!`);
                }
            });
        },
        (count) => {
            return `Steal ${count * 5} [/status/Consumed_Bloodfeast] Consumed Bloodfeast from target.`;
        },
        ["Clash Win", "Clash Lose"], false, 5, false, true
    ),
    new Effect(
        'Exsanguinate - S',
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.actor.writeExsanguinate("Slash", count * 2);
            })
        },
        (count) => {
            return `Until your next round, [/damageTypes/Slash] Slash attacks inflict ${count * 2} [/status/Bleed] Bleed.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        'Exsanguinate - P',
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.actor.writeExsanguinate("Pierce", count * 2);
            })
        },
        (count) => {
            return `Until your next round, [/damageTypes/Pierce] Pierce attacks inflict ${count * 2} [/status/Bleed] Bleed.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        'Exsanguinate - B',
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.actor.writeExsanguinate("Blunt", count * 2);
            })
        },
        (count) => {
            return `Until your next round, [/damageTypes/Blunt] Blunt attacks inflict ${count * 2} [/status/Bleed] Bleed.`
        },
        ["Clash Win"],
        false, 5, false, true
    ),
    new Effect(
        'Gain Heal Efficiency',
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Heal_Efficiency", -count, false);
        },
        (count) => {
            return `Gain ${count} [/status/Heal_Efficiency] Heal Efficiency.`;
        },
        ["Clash Win", "Clash Lose"], false, 5
    ),
    new Effect(
        'Consume SP',
        (context, count, trigger) => {
            context.triggers[trigger].spHeal = Number(context.triggers[trigger].spHeal) - count;
        },
        (count) => {
            return `Take ${count} SP damage.`
        },
        ["On Use"], false, 5
    ),
    //
    new Effect(
        'Battery',
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Charge", count * -4, false);
        },
        (count) => {
            return `Gain ${count * 4} [/status/Charge] Charge.`
        },
        ["On Use"], false, 5
    ),
    new Effect(
        'Enkephalin Syringe',
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let roll = new Roll(`${count * 2}d6+${context.actor.system.abilities.Charm.value}`);
                let res = await roll.evaluate();
                let heal = res.total;

                let target = await findAllyTarget(context.actor, "Choose an ally to use Enkephalin Syringe on.");
                await target.heal(0, heal, 0, context.actor);
                createEffectsMessage(target.name, `Recovers ${heal} ST from ${context.actor.name}'s T${count} Enkephalin Syringe!`);
            });
        },
        (count) => {
            return `Recover ${count * 2}d6+Charm ST to self or an ally.`
        },
        ["On Use"], false, 5, false, true
    ),
    new Effect(
        'Medkit',
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let roll = new Roll(`${count * 4}d6+${context.actor.system.abilities.Prudence.value * 3}`);
                let res = await roll.evaluate();
                let heal = res.total;

                let target = await findAllyTarget(context.actor, "Choose an ally to use Medkit on.");
                await target.heal(heal, 0, 0, context.actor);
                createEffectsMessage(target.name, `Recovers ${heal} HP from ${context.actor.name}'s T${count} Medkit!`);
            });
        },
        (count) => {
            return `Recover ${count * 4}d6+(Prudence * 3) HP to self or an ally.`
        },
        ["On Use"], false, 5, false, true
    ),
    new Effect(
        'Cigarettes',
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction("Smoke", -1, false);
            context.triggers[trigger].spHeal = Number(context.triggers[trigger].spHeal) + 1;
        },
        (count) => {
            return `Gain 1 [/status/Smoke] Smoke and recover 1 SP.`
        },
        ["On Use"], false, 1
    ),
    simpleStatusEffect("Poison", false, true),
    markerEffect("Poison+", false, 3),
    skillBonusEffect("Poison", 10, 5, 3),
    new Effect(
        "Strengthening Toxicant",
        (context, count, trigger) => {
            context.events["On Use"].push(async (context) => {
                let poison = context.target.getStatusCount("Poison");

                if (poison >= 20) {
                    let bonus = Math.floor((poison / 10));
                    await context.actor.applyStatus("Strength", bonus, false);
                    createEffectsMessage(context.actor.name, `Gains ${bonus} [/status/Strength] Strength from Strengthening Toxicant!`);
                }
            });
        },
        (count) => {
            return `If the target has 20+ [/status/Poison] Poison, gain [/status/Strength] Strength equal to half the [/status/Poison] Poison damage dealt this clash.`
        },
        ["On Use"], false, 1, false, true
    ),
    markerEffect("Stimulants", false, 5, "Effective Heal", count => {
        return `Apply ${count} [/status/Strength] Strength and ${count} [/status/Endurance] Endurance next round.`;
    }),
    markerEffect("Operation", false, 4, "Effective Heal", count => {
        return `Increase healing by ${count * 3} if the target is below ${100 * (1 - (0.2 * count))}% HP.`;
    }),
    new Effect(
        "Pooling Poison",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let decay = 2 * count;
                let poison = context.target.getStatusCount("Poison");

                if (poison >= decay) {
                    await context.target.reduceStatus("Poison", decay);
                    createEffectsMessage(context.actor.name, `Drains ${decay} [/status/Poison] Poison from ${context.target.name} to create ${decay} SQR of Toxic Fumes!`);
                }
            });
        },
        (count) => {
            return `Drain ${count * 2} [/status/Poison] Poison from the target to create ${count * 2} SQR of Toxic Fumes nearby.`;
        },
        ["On Use"],
        false,
        5, false, true
    ),
    markerEffect("Absolve Sorrow", false, 1, "On Crit", (count) => {
        return `Do not deal [/status/Critical] Critical damage. Burst [/status/Sinking] Sinking once for every [/status/Critical] Critical on self.`
    }),
    new Effect(
        "Multihit Devastation",
        (context, count, trigger) => {
            
        },
        (count) => {
            return '[/status/Devastation] Devastation from this skill applies on multi-hit attacks.'
        },
        ["On Use"],
        false, 1, false, true, 0, true
    ),
    new Effect(
        "Adaptation - S",
        (context, count, trigger) => {
            context.damageType = "Slash";
        },
        (count) => {
            return 'Damage Type becomes [/damageTypes/Slash] Slash.'
        },
        ["On Use"], false, 1, false
    ),
    new Effect(
        "Adaptation - P",
        (context, count, trigger) => {
            context.damageType = "Pierce";
        },
        (count) => {
            return 'Damage Type becomes [/damageTypes/Pierce] Pierce.'
        },
        ["On Use"], false, 1, false
    ),
    new Effect(
        "Adaptation - B",
        (context, count, trigger) => {
            context.damageType = "Blunt";
        },
        (count) => {
            return 'Damage Type becomes [/damageTypes/Blunt] Blunt.'
        },
        ["On Use"], false, 1, false
    ),
    new Effect(
        "Push",
        (context, count, trigger) => {
            context.events["Clash Win"].push(async (context) => {
                createEffectsMessage(context.target.name, `Is pushed ${count} SQR by the attack!`);
                await requestForcedMovement(context.actor, context.target, context.target, count, true, true);
            });
        },
        (count) => {
            return `Push the target ${Number(count)} SQR.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    ),
    new Effect(
        "Bloodclot",
        (context, count, trigger) => {
            if (context.target != null && context.target.getStatusCount("Consumed_Bloodfeast") > 20) {
                context.dicePower = Number(context.dicePower) + Math.floor(context.target.getStatusCount("Consumed_Bloodfeast") / 20);
                context.skillDicePower = Number(context.skillDicePower) + Math.floor(context.target.getStatusCount("Consumed_Bloodfeast") / 20);
            }
        },
        (count) => {
            return `Gain 1 Dice Power for every 20 [/status/Consumed_Bloodfeast] Consumed Bloodfeast on target.`;
        },
        ["On Use"], false, 1
    ),
    new Effect(
        "Lethal Dose",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                await context.target.addEffectTrigger("Lethal Dose");
            });

            context.events["On Use"].push(async (context) => {
                await context.target.addEffectTrigger("Skip Next Poison");
            });
        },
        (count) => {
            return `Deal HP damage equal to half of target's [/status/Poison] Poison on next [/status/Poison] Poison proc. Do not trigger [/status/Poison] Poison this clash.`;
        },
        ["Clash Win"], false, 1, false, true
    ),
    new Effect(
        "Staggering Toxin",
        (context, count, trigger) => {
            context.events["On Use"].push(async (context) => {
                await context.target.addEffectTrigger("Staggering Toxin");
            });
        },
        (count) => {
            return `Deal ST damage equal to [/status/Poison] Poison damage dealt.`;
        },
        ["On Use"], false, 1, false, true
    ),
    new Effect(
        "Depressing Bane",
        (context, count, trigger) => {
            context.events["On Use"].push(async (context) => {
                await context.target.addEffectTrigger("Depressing Bane");
            });
        },
        (count) => {
            return `Deal SP damage equal to [/status/Poison] Poison damage dealt.`;
        },
        ["On Use"], false, 1, false, true
    ),
    new Effect(
        "Centipede Venom",
        (context, count, trigger) => {
            context.events["On Use"].push(async (context) => {
                await context.target.addEffectTrigger("Centipede Venom");
            });
        },
        (count) => {
            return `Inflict [/status/Disarm] Disarm equal to half of [/status/Poison] Poison damage dealt.`;
        },
        ["On Use"], false, 1, false, true
    ),
    new Effect(
        "Spark Discharge",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let charge = await context.actor.getStatusCount("Charge");
                await context.actor.reduceStatus("Charge", charge);
                await context.target.takeDamageStatus(charge, "", "HP", "[/status/Charge] Takes %DMG% HP damage from Spark Discharge! (%PHP% -> %HP%)");
                await context.actor.takeDamageStatus(Math.floor(charge / 2), "", "HP", "[/status/Charge] Takes %DMG% HP damage from Spark Discharge! (%PHP% -> %HP%)");
            });
        },
        (count) => {
            return `Spend all [/status/Charge] Charge. The target receives HP damage equal to [/status/Charge] Charge spent, and the user receives half of that damage.`;
        },
        ["Clash Win", "Clash Lose"], false, 1, false, true
    ),
    new Effect(
        "Slip Past",
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                let c = context.getRange() + 2;
                let token = await pollUserRequestTargeting(context.actor, TargetType.TOKEN, {
                    originToken: getActorToken(context.actor),
                    maxRange: c,
                    enforceRange: false,
                    requireLOS: false
                });

                if (token != null) {
                    token = canvas.tokens.placeables.find(x => x.id == token);
                    let pointA = getTokenCenter(getActorToken(context.actor));
                    let pointB = getTokenCenter(token);

                    await teleportToken(token, pointA);
                    await teleportToken(getActorToken(context.actor), pointB);

                    createEffectsMessage(context.actor.name, `${context.actor.name} switches places with ${token.actor.name}!`);
                }
            });
        },
        (count) => {
            return `Swap places with a target in your melee range + 1 SQR.`; 
        },
        ["Clash Win", "Clash Lose"], false, 1, false, true
    ),
    new Effect(
        "Discard - Reaction Cost",
        (context, count, trigger) => {
            if (!context.flags.includes("Discard Reaction")) {
                context.costs.push({
                    cost: count,
                    status: "Discard",
                    free: true
                })
                context.flags.push("Discard Reaction");
            }

            context.events[trigger].push(async (context) => {
                await context.actor.discardReactions(count);
            });
        },
        (count) => {
            return `Discard ${count} Reactions.`
        },
        ["On Use"], false, 5, false, true
    ),
    new Effect(
        "Discard - Dice Power Up",
        (context, count, trigger) => {
            let rcount = context.getDiscardCost();
            context.dicePower = Number(context.dicePower) + rcount;
            context.skillDicePower = Number(context.skillDicePower) + rcount;
        },
        (count) => {
            return `Gain 1 Dice Power for every Reaction this skill discarded.`
        },
        ["On Use"], false, 1
    )
]

async function findAllyTarget(actor, msg) {
    let team = findActorsOfTeam(actor);
    team.push(actor);
    let options = [];
    let map = [];

    for (let member of team) {
        options.push({ name: member.system.id, displayName: member.name });
        map[member.system.id] = member;
    }

    let target = await pollUserInputOptions(actor, msg, options);
    target = map[target];

    return target;
}

function healEffect(val, cat) {
    return new Effect(
        `Regen ${cat}`,
        (context, count, trigger) => {
            if (count < 0) {
                context.events[trigger].push(async (context) => {
                    await context.actor.takeDamageStatus(val, "none", cat, `Takes %DMG% ${cat} damage! (%P${cat}% -> %${cat}%)`);
                });
            }
            else if (count > 0 && !context.flags.includes(`performed${cat}Regen`)) {
                context.flags.push(`performed${cat}Regen`);
                switch (cat) {
                    case "HP":
                        context.triggers[trigger].hpHeal = Number(context.triggers[trigger].hpHeal) + (count * val);
                        break;
                    case "ST":
                        context.triggers[trigger].stHeal = Number(context.triggers[trigger].stHeal) + (count * val);
                        break;
                    case "SP":
                        context.triggers[trigger].spHeal = Number(context.triggers[trigger].spHeal) + (count * val);
                        break;
                }
            }
        },
        (count) => {
            return count < 0 ? `Take ${Number(count) * val} ${cat} damage` : `Recover ${Number(count) * val} ${cat}`;
        },
        ["Clash Win", "Clash Lose", "On Use"],
        true, 5, false, true
    );
}

function chargeInflictStatus(name, cost, nextRound = false) {
    return chargeEffect(`Charge - ${name}`, cost,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction(name.replace(" ", "_"), count, nextRound);
        },
        count => `inflict ${Number(count)} [/status/${name.replace(" ", "_")}] ${name}${nextRound ? " next round" : ""}`
    );
}

function overchargeEffectEvent(name, cost, func, desc, triggers = ["Clash Win", "Clash Lose"], maxCount = 5, scale = false) {
    return new Effect(
        name,
        (context, count, trigger) => {
            if (!context.flags.includes(name)) {
                context.costs.push({
                    cost: scale ? cost * count : cost,
                    status: "Overcharge",
                })
                context.flags.push(name);
            }

            func(context, count, trigger);
        },
        (count) => {
            return `Consume ${scale ? cost * count : cost} [/status/Overcharge] Overcharge to ` + desc(count);
        },
        triggers,
        false, maxCount, false, true
    );
}

function overchargeEffect(name, cost, func, desc, triggers = ["Clash Win", "Clash Lose"], maxCount = 5, scale = false) {
    return new Effect(
        name,
        (context, count, trigger) => {
            context.costs.push({
                cost: scale ? cost * count : cost,
                status: "Overcharge",
            })

            func(context, count, trigger);
        },
        (count) => {
            return `Consume ${scale ? cost * count : cost} [/status/Overcharge] Overcharge to ` + desc(count);
        },
        triggers,
        false, maxCount
    );
}

function chargeEffect(name, cost, func, desc, triggers = ["Clash Win", "Clash Lose"], maxCount = 5) {
    return new Effect(
        name,
        (context, count, trigger) => {
            context.costs.push({
                cost: cost * count,
                status: "Charge",
            })

            func(context, count, trigger);
        },
        (count) => {
            return `Consume ${cost * count} [/status/Charge] Charge to ` + desc(count);
        },
        triggers,
        false, maxCount
    );
}

function chargeEffectEvent(name, cost, func, desc, triggers = ["Clash Win", "Clash Lose"], maxCount = 5) {
    return new Effect(
        name,
        (context, count, trigger) => {
            if (!context.flags.includes(name)) {
                context.costs.push({
                    cost: cost * count,
                    status: "Charge",
                })

                context.flags.push(name);
            }

            func(context, count, trigger);
        },
        (count) => {
            return `Consume ${cost * count} [/status/Charge] Charge to ` + desc(count);
        },
        triggers,
        false, maxCount, false, true
    );
}

function markEffect(name, func, desc) {
    return new Effect(
        name,
        (context, count, trigger) => {
            if (context.target && context.actor.isMarkedTarget(context.target)) {
                func(context.triggers[trigger], count);
            }
        },
        (count) => {
            return `Against marked target, ` + desc(count);
        },
        ["Clash Win", "Clash Lose"],
        false, 5
    );
}

function simpleStatusEffectSelf(status, amount, altStatus = null) {
    return new Effect(
        `${status}`,
        (context, count, trigger) => {
            if (count < 0) {
                context.triggers[trigger].applyInfliction(altStatus.replace(" ", "_"), -amount, true);
            }
            else {
                context.triggers[trigger].applyInfliction(status.replace(" ", "_"), -amount, true);
            }
        },
        (count) => {
            return count < 0 ? `Gain ${Math.abs(Number(count))} [/status/${altStatus.replace(" ", "_")}] ${altStatus} next round.` : `Gain ${Number(count)} [/status/${status.replace(" ", "_")}] ${status} next round.`;
        },
        ["Clash Win", "Clash Lose"],
        altStatus != null, 5, false, false
    );
}

function smokeStatusEffectSelf(status, amount, nextRound, smokeReq) {
    return new Effect(
        `Smoke - ${status}`,
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let req = smokeReq * count;
                if (ctx.target.getStatusCount("Smoke") >= req) {
                    await ctx.target.reduceStatus("Smoke", req);
                }
                
                data.applyInfliction(status.replace(" ", "_"), -(count * amount), nextRound);
            });
        },
        (count) => {
            return `Spend ${smokeReq * count} [/status/Smoke] to gain ${amount * count} [/status/${status.replace(" ", "_")}] ${status}${nextRound ? " next round." : "."}`;
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    );
}

function smokeStatusEffect(status, amount, nextRound, smokeReq) {
    return new Effect(
        `Smoke - ${status}`,
        (context, count, trigger) => {
            context.triggers[trigger].modify.push(async (ctx, data) => {
                let req = smokeReq * count;
                if (ctx.target.getStatusCount("Smoke") >= req) {
                    await ctx.target.reduceStatus("Smoke", req);
                }

                data.applyInfliction(status.replace(" ", "_"), count * amount, nextRound);
            });
        },
        (count) => {
            return `Spend ${smokeReq * count} [/status/Smoke] to inflict ${amount * count} [/status/${status.replace(" ", "_")}] ${status}${nextRound ? " next round." : "."}`;
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    );
}

function simpleStatusEffect(status, nextRound, allowNegative, nameOverride = null) {
    let str = nextRound ? " next round" : "";
    return new Effect(
        nameOverride != null ? nameOverride : `Inflict ${status}`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction(status.replace(" ", "_"), count, nextRound);
        },
        (count) => {
            return handleNegativeText(
                `Inflict % [/status/${status.replace(" ", "_")}] ${status}` + str, 
                `Gain % [/status/${status.replace(" ", "_")}] ${status}` + str, 
            count);
        },
        ["Clash Win", "Clash Lose"],
        allowNegative, status == "Rupture" ? 6 : 5
    );
}

function chargeAllyStatusEffect(status, cost, mult, nextRound) {
    let str = nextRound ? " next round" : "";
    return new Effect(
        `Charge - ${status}`,
        (context, count, trigger) => {
            context.costs.push({
                cost: cost * count,
                status: "Charge",
            })

            context.events[trigger].push(async (context) => {
                if (status == "[Type] Protection") {
                    let status = await pollUserInputOptions(ctx.actor, "Choose [Type] Protection to apply.", [
                        {
                            name: "Slash Protection",
                            icon: "/status/Slash_Protection.png"
                        },
                        {
                            name: "Pierce Protection",
                            icon: "/status/Pierce_Protection.png"
                        },
                        {
                            name: "Blunt Protection",
                            icon: "/status/Blunt_Protection.png"
                        },
                    ]);
                }

                let results = await pollDistributeStatus(context.actor, getActorTeam(context.actor), status, count * mult);
                let text = "";
                for (let res of results) {
                    let actor = findByID(res.system.id);
                    await actor.applyStatus(status.replace(" ", "_"), nextRound ? 0 : res.allocated, nextRound ? res.allocated : 0);
                    await context.actor.handleMarkAid(actor);
                    text = text + `${res.name} receives ${res.allocated} [/status/${status.replace(" ", "_")}] ${status}${nextRound ? " next round" : ""}!` + "\n";
                }

                createEffectsMessage(context.actor.name, text);
            });
        },
        (count) => {
            return `Spend ${cost * count} to distribute ${Number(count) * mult} [/status/${status.replace(" ", "_")}] ${status} ${nextRound ? "next round " : ""}amongst allies.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    );
}

function allyStatusEffect(status, mult, nextRound) {
    let str = nextRound ? " next round" : "";
    return new Effect(
        `Give ${status}`,
        (context, count, trigger) => {
            context.events[trigger].push(async (context) => {
                if (status == "[Type] Protection") {
                    let status = await pollUserInputOptions(ctx.actor, "Choose [Type] Protection to apply.", [
                        {
                            name: "Slash Protection",
                            icon: "/status/Slash_Protection.png"
                        },
                        {
                            name: "Pierce Protection",
                            icon: "/status/Pierce_Protection.png"
                        },
                        {
                            name: "Blunt Protection",
                            icon: "/status/Blunt_Protection.png"
                        },
                    ]);
                }

                let results = await pollDistributeStatus(context.actor, getActorTeam(context.actor), status, count * mult);
                let text = "";
                for (let res of results) {
                    let actor = findByID(res.system.id);
                    await actor.applyStatus(status.replace(" ", "_"), nextRound ? 0 : res.allocated, nextRound ? res.allocated : 0);
                    await context.actor.handleMarkAid(actor);
                    text = text + `${res.name} receives ${res.allocated} [/status/${status.replace(" ", "_")}] ${status}${nextRound ? " next round" : ""}!` + "\n";
                }

                createEffectsMessage(context.actor.name, text);
            });
        },
        (count) => {
            return `Distribute ${Number(count) * mult} [/status/${status.replace(" ", "_")}] ${status} ${nextRound ? "next round " : ""}amongst allies.`
        },
        ["Clash Win", "Clash Lose"],
        false, 5, false, true
    );
}

function statusPauseEffect(status, max = 5) {
    return new Effect(
        `${status}`,
        (context, count, trigger) => {
            context.triggers[trigger].applyInfliction(status.replace(" ", "_"), count, false);
        },
        (count) => {
            return `Inflict ${Number(count)} [/status/${status.replace(" ", "_")}] ${status}.`
        },
        ["Clash Win"],
        false, max
    );
}


async function applyInAoe(origin, distance, callback, user) {
    let source = getCombatantTokens().find(x => x.actor == origin);
    let dispo = 0;
    if (user != null) {
        dispo = getCombatantTokens().find(x => x.actor == user).document.disposition;
    }

    for (let token of getCombatantTokens().filter(x => user == null ? true : x.document.disposition != dispo)) {
        if (token.actor == null) continue;
        if (scale(canvas.grid.measureDistance(source, token)) <= distance) {
            await callback(token.actor);
        }
    }
}

function markerEffect(name, negative = false, count = 1, trigger = "Always Active", desc = null) {
    return new Effect(
        name,
        (context, count, trigger) => { },
        desc,
        [trigger],
        negative,
        count
    );
}

function skillVigorEffect(status, req, dupReq, multReq = 1) {
    return new Effect(
        `${status} Vigor`,
        (context, count, trigger) => {
            if (context.actor != null) {
                let stacks = context.actor.getStatusCount(status);
                let req2 = context.actor.augmentEffectCount(`${status} Vigor`) > 0 ? req + dupReq + (count * multReq) : req;

                if (stacks >= req2) {
                    context.dicePower = Number(context.dicePower) + count;
                    context.skillDicePower = Number(context.skillDicePower) + count;
                }
            }
        },
        (count) => {
            return `Gain ${Number(count)} Dice Power if the user has ${req + (count * multReq)} [/status/${status}] ${status}.`
        },
        ["On Use"],
        false,
        5
    );
}

function skillBonusEffect(status, req, max = 5, multReq = 1) {
    return new Effect(
        `${status} Bonus`,
        (context, count, trigger) => {
            if (context.target != null && context.target.getStatusCount(status) >= req + (count * multReq)) {
                context.dicePower = Number(context.dicePower) + count;
                context.skillDicePower = Number(context.skillDicePower) + count;
            }
        },
        (count) => {
            return `If the target has ${(req + (count * multReq)) > 1 ? (req + (count * multReq)) + " " : ""}[/status/${status}] ${status}, gain ${Number(count)} Dice Power`
        },
        ["On Use"],
        false,
        5
    );
}