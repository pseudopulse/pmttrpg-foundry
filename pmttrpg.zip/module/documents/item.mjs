// import { Roll } from "@client/dice/_module.mjs";
// import { Token } from "@client/config.mjs";
// import { ChatMessage } from "@client/config.mjs";
import { RollContext } from "../core/combat/rollContext.mjs";
import { requestTargeting, TargetType } from "../core/combat/targeting.mjs";
import { createClashMessage, createEffectsMessage } from "../core/helpers/clash.mjs";
import { createAlertBox, getActionModifiers, pollUserInputConfirm, pollUserInputOptions } from "../core/helpers/dialog.mjs";
import { sendNetworkMessage } from "../core/helpers/netmsg.mjs";
import { Triggers } from "../core/status/statusEffect.mjs";
import { findItemOwner, getActorToken } from "../pmttrpg.mjs";

//
export class PTItem extends Item {
    static get defaultType() {
        return "weapon";
    }

    prepareDerivedData() {
        super.prepareDerivedData();
        const itemData = this;
        const systemData = itemData.system;
    }

    async roll(initiator = true, defType = "Block", enemyCtx = null) {
        switch (this.type) {
            case "weapon":
                return await this.handleUsageWeapon(initiator, enemyCtx);
                break;
            case "outfit":
                return await this.handleUsageOutfit(defType, enemyCtx);
                break;
            default:
                break;
        }
    }

    async handleUsageOutfit(defType, enemyCtx = null) {
        const item = this;

        const speaker = ChatMessage.getSpeaker({ actor: this.actor });
        const rollMode = game.settings.get('core', 'rollMode');

        if (game.user.targets.first() == null) {
            createAlertBox("You must designate a target before defending!");
            return false;
        }

        const context = defType == "Block" ? await this.getRollContextBlo(game.user.targets.first().actor, true) : await this.getRollContextEvd(game.user.targets.first().actor, true);

        if (context == null) {
            await this.actor.handlePendingClash(enemyCtx);
            return false;
        }

        if (this.actor.getHasRecycledEvade() && context.modifiers.item == null) {
            let res = await pollUserInputConfirm(this.actor, `Use your Recycled Evade for this clash? (Recycled ${this.actor.getRecycledEvadeCount()} times)`);

            if (res) {
                context.recycledEvade = true;
                await this.actor.incRecycledEvadeCount();
                let count = this.actor.getRecycledEvadeCount();

                context.dicePower = Number(context.dicePower) - (context.form == "Swift" ? count : count * 2);
            }
        }

        if (defType != "Evade") {
            await this.actor.setRecycledEvadeStatus(false);
        }
        
        const label = `[${item.type}] ${item.name} targeting ${game.user.targets.first().actor.name}`;

        const roll = new Roll(`1d${context.diceMax}+${context.dicePower}`, "");
        let result = await roll.evaluate();

        if (enemyCtx != null) {
            context.forcedAdvState += enemyCtx.enemyAdvState;
            context.modifierText = enemyCtx.enemyModifierText;
        }

        context.isReaction = true;
        // await this.actor.spendReaction(true, false);

        if (context.forcedAdvState != 0 || this.actor.getStatusCount("Paralysis") > 0) {
            const reroll = await new Roll(`1d${context.diceMax}+${context.dicePower}`, "").evaluate();

            if (context.forcedAdvState > 0) {
                result = result.total > reroll.total ? result : reroll;
            }
            else if (context.forcedAdvState < 0) {
                result = result.total > reroll.total ? reroll : result;
            }
            else {
                if (this.actor.augmentEffectCount("Energy Intake") > 0) {
                    await this.actor.applyStatus("Charge", 4);
                    createEffectsMessage(this.actor.name, `Gains 4 [/status/Charge] Charge from Energy Intake!`);
                }
                
                await this.actor.reduceStatus("Paralysis", 1);
                result = result.total > reroll.total ? reroll : result;
            }
        }

        context.result = result.total;
        context.applyClashEffects = true;

        createClashMessage(this.actor, context);
        await this.actor.queueRoll(context);

        await this.actor.assignRecycleableAction(context, defType, item);

        return true;
    }

    async handleUsageWeapon(initiator, enemyCtx = null) {
        const item = this;

        const speaker = ChatMessage.getSpeaker({ actor: this.actor });
        const rollMode = game.settings.get('core', 'rollMode');

        if (game.user.targets.first() == null) {
            createAlertBox("You must designate a target before attacking!");
            return false;
        }

        if (game.user.targets.first().actor == this.actor) {
            createAlertBox("You can't attack yourself!");
            return false;
        }

        const context = await this.getRollContext(game.user.targets.first().actor, true);

        if (context == null) {
            if (initiator) {
                return false;
            }
            else {
                return false;
            }
        }

        const label = `[${item.type}] ${item.name} targeting ${game.user.targets.first().actor.name}`;

        const roll = new Roll(`1d${context.diceMax}+${context.dicePower}`, "");
        let result = await roll.evaluate();

        if (enemyCtx != null) {
            context.forcedAdvState += enemyCtx.enemyAdvState;
            context.modifierText = enemyCtx.enemyModifierText;
        }

        if (context.forcedAdvState != 0 || this.actor.getStatusCount("Paralysis") > 0) {
            const reroll = await new Roll(`1d${context.diceMax}+${context.dicePower}`, "").evaluate();

            if (context.forcedAdvState > 0) {
                result = result.total > reroll.total ? result : reroll;
            }
            else if (context.forcedAdvState < 0) {
                result = result.total > reroll.total ? reroll : result;
            }
            else {
                if (this.actor.augmentEffectCount("Energy Intake") > 0) {
                    await this.actor.applyStatus("Charge", 4);
                    createEffectsMessage(this.actor.name, `Gains 4 [/status/Charge] Charge from Energy Intake!`);
                }

                await this.actor.reduceStatus("Paralysis", 1);
                result = result.total > reroll.total ? reroll : result;
            }
        }

        context.result = result.total;
        context.applyClashEffects = true;

        if (this.actor.read("nextDualWield")) {
            await this.actor.write("nextDualWield", false);
            context.isDualWield = true;
        }

        if (context.hasEffect("Overheat")) {
            await this.actor.overheatWeapon(this);
        }

        if (initiator) {
            sendNetworkMessage("PENDING_CLASH", {
                attacker: this.actor.system.id,
                target: game.user.targets.first().actor.system.id,
                context: context,
            })

            // await this.actor.spendAction();
        }
        else {
            context.isReaction = true;
            await this.actor.setRecycledEvadeStatus(false);
            // await this.actor.spendReaction(true, false);
        }

        await this.actor.queueRoll(context);

        await this.actor.assignRecycleableAction(context, "Attack", item);

        createClashMessage(this.actor, context);

        return true;
    }

    async getRollContext(target = null, rollSkill = false) {
        const itemData = this;
        const systemData = itemData.system;
        const rollContext = new RollContext();
        rollContext.damageType = systemData.damageType;
        rollContext.name = this.name;
        rollContext.actor = this.actor;
        rollContext.target = target;
        rollContext.type = systemData.attackType;
        rollContext.attackType = systemData.attackType;
        rollContext.form = systemData.form;
        rollContext.hand = systemData.hand;

        if (rollContext.form == "Hybrid") {
            rollContext.attackType = await pollUserInputOptions(this.actor, "Select attack type for hybrid weapon.", [{ name: "Melee" }, { name: "Ranged" }], 0);
            rollContext.type = rollContext.attackType;
        }

        if (rollSkill) {
            const tmpCtx = new RollContext();
            Object.assign(tmpCtx, JSON.parse(JSON.stringify(rollContext)));
            await tmpCtx.fix();
            tmpCtx.addEffectsList(systemData.effects, fixTypeName(this.type));
            await tmpCtx.processEffects();
            rollContext.modifiers = await getActionModifiers(this.actor, tmpCtx);
            if (rollContext.modifiers == null) {
                return null;
            }
        }

        rollContext.addEffectsList(systemData.effects, fixTypeName(this.type));
        await rollContext.processEffects();

        await rollContext.fireEvent("Before Attack");

        if (rollContext.hasEffect("Extra DMG Type") || rollContext.hasEffect("Versatility") || (rollContext.attackType == "Ranged" && (!rollContext.hasEffect("Charge Ammo") && !rollContext.hasEffect("Coagulated Bullets") && !rollContext.hasEffect("Smoke Cartridge")))) {
            rollContext.damageType = await pollUserInputOptions(game.user, "Select Damage Type", [
                {
                    name: "Slash",
                    icon: "/damageTypes/Slash.png"
                },
                {
                    name: "Pierce",
                    icon: "/damageTypes/Pierce.png"
                },
                {
                    name: "Blunt",
                    icon: "/damageTypes/Blunt.png"
                },
            ], ["Slash", "Pierce", "Blunt"].indexOf(rollContext.damageType));
        }

        if (!rollContext.hasEffect("Coagulated Bullets") && (rollContext.attackType == "Ranged" || rollContext.hasEffect("Ballistic") || rollContext.hasEffect("Loaded Salvo")) && (!rollContext.hasEffect("Charge Ammo") || (this.actor.augmentEffectCount("Ammo Infusion") > 0 || this.actor.augmentEffectCount("Ammo Infusion Alt")))) {
            if (rollContext.hasEffect("Charge Ammo")) {
                let cost = 2;
                if (((this.actor.augmentEffectCount("Ammo Infusion") > 0 && this.actor.getStatusCount("Charge") >= 6) || (this.actor.augmentEffectCount("Ammo Infusion Alt") && this.actor.getStatusCount("Charge") >= 4))) {
                    let bullet = await rollContext.loadBullet();
                    if (bullet != "Standard") {
                        if (this.actor.augmentEffectCount("Ammo Infusion") > 0) {
                            cost = 6;
                        }
                        else {
                            cost = 4;
                        }
                    }
                }

                await this.actor.reduceStatus("Charge", cost);
                createEffectsMessage(this.actor.name, `Spends ${cost} [/status/Charge] Charge to create ammo!`);
            }
            else {
                await rollContext.loadBullet();
            }
        }

        if (rollContext.hasEffect("Coagulated Bullets") && rollContext.attackType == "Ranged") {
            let cost = 12 - (rollContext.effectCount("Coagulated Bullets") * 2);

            await this.actor.spendBloodfeast(cost);
            createEffectsMessage(this.actor.name, `Consumes ${cost} [/status/Bloodfeast] Bloodfeast to form coagulated bullets!`);
        }

        if (rollContext.hasEffect("Charged Blade") && rollContext.attackType == "Melee") {
            let count = 1 + Number(rollContext.effects.find(x => x.name == "Charged Blade").count);
            await this.actor.reduceStatus("Charge", count);
            createEffectsMessage(this.actor.name, `Spends ${count} [/status/Charge] Charge to wield their weapon!`);
        }

        if (rollContext.form == "Psionic (M)") {
            await this.actor.takeDamage(0, null, 0, 0, 2);
        }
        else if (rollContext.form == "Psionic") {
            await this.actor.takeDamage(0, null, 0, 0, 4);
        }

        /*if (rollContext.targetCount > 1) {
            let targets = await requestTargeting(TargetType.MULTI_TOKEN, {
                maxRange: rollContext.targetingRange,
                maxSelections: rollContext.targetCount,
                requireLOS: true,
                extraNotification: "Select sub-targets for attack.",
                originToken: getActorToken(rollContext.targetingOrigin),
            });

            for (let target of targets) {
                rollContext.targets.push(target.actor);
                rollContext.targetIDs = targets.map(x => x.actor.system.id);
            }

            canvas.tokens.placeables.find(x => x.actor && x.actor.system.id == rollContext.target.system.id).setTarget(true, { releaseOthers: true });
        }*/

        return rollContext;
    }

    async getRollContextBlo(target = null, rollSkill = false) {
        const itemData = this;
        const systemData = itemData.system;
        const rollContext = new RollContext();
        rollContext.damageType = systemData.damageType;
        rollContext.name = this.name;
        rollContext.actor = this.actor;
        rollContext.target = target;
        rollContext.damageType = "Block";
        rollContext.type = "Block";
        rollContext.form = systemData.form;
        rollContext.hand = systemData.hand;

        if (rollSkill) {
            const tmpCtx = new RollContext();
            Object.assign(tmpCtx, JSON.parse(JSON.stringify(rollContext)));
            await tmpCtx.fix();
            tmpCtx.addEffectsList(systemData.effects, fixTypeName(this.type));
            await tmpCtx.processEffects();
            rollContext.modifiers = await getActionModifiers(this.actor, tmpCtx);
            if (rollContext.modifiers == null) {
                return null;
            }
        }

        rollContext.addEffectsList(systemData.effects, fixTypeName(this.type));
        await rollContext.processEffects();
        return rollContext;
    }

    async getRollContextEvd(target = null, rollSkill = false) {
        const itemData = this;
        const systemData = itemData.system;
        const rollContext = new RollContext();
        rollContext.damageType = systemData.damageType;
        rollContext.name = this.name;
        rollContext.actor = this.actor;
        rollContext.target = target;
        rollContext.damageType = "Evade";
        rollContext.type = "Evade";
        rollContext.form = systemData.form;
        rollContext.hand = systemData.hand;

        if (rollSkill) {
            const tmpCtx = new RollContext();
            Object.assign(tmpCtx, JSON.parse(JSON.stringify(rollContext)));
            await tmpCtx.fix();
            tmpCtx.addEffectsList(systemData.effects, fixTypeName(this.type));
            await tmpCtx.processEffects();
            rollContext.modifiers = await getActionModifiers(this.actor, tmpCtx);
            if (rollContext.modifiers == null) {
                return null;
            }
        }

        rollContext.addEffectsList(systemData.effects, fixTypeName(this.type));
        await rollContext.processEffects();
        return rollContext;
    }
}

function fixTypeName(val) {
    return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}

export function getRollContextFromData(item, def = false, defType = "Block") {
    if (item.type == null) {
        item = item.item;
    }

    const itemData = item;
    const systemData = itemData.system;
    const rollContext = new RollContext();
    rollContext.addEffectsList(systemData.effects, fixTypeName(item.type));
    rollContext.actor = findItemOwner(item);
    rollContext.damageType = def ? defType : systemData.damageType;
    rollContext.type = def ? defType : systemData.attackType;
    rollContext.name = item.name;
    rollContext.attackType = systemData.attackType;
    rollContext.form = systemData.form;
    rollContext.hand = systemData.hand;

    rollContext.processEffectsSync();

    rollContext.mergeCosts();
    return rollContext;
}

export async function getRollContextFromDataFullTargeted(item, target, def = false, defType = "Block") {
    if (item.type == null) {
        item = item.item;
    }

    const itemData = item;
    const systemData = itemData.system;
    const rollContext = new RollContext();
    rollContext.target = target;
    rollContext.addEffectsList(systemData.effects, fixTypeName(item.type));
    rollContext.actor = findItemOwner(item);
    rollContext.damageType = def ? defType : systemData.damageType;
    rollContext.type = def ? defType : systemData.attackType;
    rollContext.name = item.name;
    rollContext.attackType = systemData.attackType;
    rollContext.form = systemData.form;
    rollContext.hand = systemData.hand;

    await rollContext.processEffects();

    rollContext.mergeCosts();
    return rollContext;
}

export async function getRollContextFromDataFull(item, def = false, defType = "Block") {
    if (item.type == null) {
        item = item.item;
    }

    const itemData = item;
    const systemData = itemData.system;
    const rollContext = new RollContext();
    rollContext.addEffectsList(systemData.effects, fixTypeName(item.type));
    rollContext.actor = findItemOwner(item);
    rollContext.damageType = def ? defType : systemData.damageType;
    rollContext.type = def ? defType : systemData.type;
    rollContext.name = item.name;
    rollContext.attackType = systemData.type;
    rollContext.form = systemData.form;
    rollContext.hand = systemData.hand;

    await rollContext.processEffects();

    rollContext.mergeCosts();
    return rollContext;
}