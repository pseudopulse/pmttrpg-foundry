import { weaponEffects } from "./core/effects/weaponEffects.mjs";
import { PTActor } from "./documents/actor.mjs";
import { getRollContextFromData, PTItem } from "./documents/item.mjs";
import { PTActorSheet } from "./sheets/actor.mjs";
import { PTItemSheet } from "./sheets/item.mjs";
import { handler, sendNetworkMessage, registerMessages, getActorUser } from "./core/helpers/netmsg.mjs";
import { currentRound, currentTurn, roundChange, setRound, turnChange, updateCombatant } from "./core/combat/combatState.mjs";
import { getEffectsArray } from "./core/effects/effectHelpers.mjs";
import { RollContext } from "./core/combat/rollContext.mjs";
import { createEffectsMessage, enrichClashData } from "./core/helpers/clash.mjs";
import { createAlertBox } from "./core/helpers/dialog.mjs";
import { PTTokenRuler } from "./documents/tokenRuler.mjs";
import { macroList } from "./core/combat/macros.mjs";
import { Triggers } from "./core/status/statusEffect.mjs";
import { handleBarReplacement } from "./core/combat/bars.mjs";
// import Hooks from "@client/helpers/hooks.mjs";

let ignoreNextMountFlag = [];

Hooks.once("init", async () => {
  // debug
  // CONFIG.debug.hooks = true;

  game.pmttrpg = {
    macroList: macroList
  };

  //
  registerMessages();

  //
  await game.settings.register('pmttrpg', 'bloodfeast', {
    name: 'bloodfeast',
    hint: 'internal dont touch',
    config: false,
    scope: 'world',
    type: Number,
    default: 0,
    requiresReload: false
  });

  // actor stuff
  CONFIG.Actor.documentClass = PTActor;
  CONFIG.Actor.types = ["character"];

  CONFIG.Actor.trackableAttributes = {
    character: {
      bar: ["health", "stagger", "sanity"],
      value: ["xp"]
    },
  };

  Actors.unregisterSheet('core', ActorSheet);
  Actors.registerSheet('pmttrpg', PTActorSheet,
    {
      types: ["character"],
      makeDefault: true,
      label: 'PMTTRPG.SheetLabels.Actor'
    }
  );

  // item stuff
  CONFIG.Item.documentClass = PTItem;
  CONFIG.Item.types = ["weapon", "tool", "skill", "outfit", "augment", "technique"];

  Items.unregisterSheet('core', ItemSheet);
  Items.registerSheet('pmttrpg', PTItemSheet,
    {
      types: ["weapon", "tool", "skill", "outfit", "augment", "technique"],
      makeDefault: true,
      label: 'PMTTRPG.SheetLabels.Item'
    }
  )

  // combat
  CONFIG.Combat.initiative = {
    formula: '1d6 + @abilities.Justice.value + @initiativeModifier',
    decimals: 2
  };
  CONFIG.ActiveEffect.legacyTransferral = false;

  CONFIG.Token.rulerClass = PTTokenRuler;

  // handlebar utils
  Handlebars.registerHelper({
    eq: (v1, v2) => v1 === v2,
    ne: (v1, v2) => v1 !== v2,
    lt: (v1, v2) => v1 < v2,
    gt: (v1, v2) => v1 > v2,
    lte: (v1, v2) => v1 <= v2,
    gte: (v1, v2) => v1 >= v2,
    and() {
      return Array.prototype.every.call(arguments, Boolean);
    },
    or() {
      return Array.prototype.slice.call(arguments, 0, -1).some(Boolean);
    },
    effect(name, type) {
      return getEffectsArray(type).find(x => x.name == name);

      return null;
    },
    canShowEffect(name, type) {
      let effect = getEffectsArray(type).find(x => x.name == name);

      if (effect.hidden && !game.user.isGM) {
        return false;
      }

      return effect != null;
    },
    rctx(item) {
      let ctx = getRollContextFromData(item);
      ctx.item = item;
      return ctx;
    },
    drctx(item, type) {
      return getRollContextFromData(item, true, type);
    },
    reslook(item, type, cat) {
      switch (type) {
        case "Slash":
          return cat == "Stg" ? item.slashResST : item.slashRes;
        case "Pierce":
          return cat == "Stg" ? item.pierceResST : item.pierceRes;
        case "Blunt":
          return cat == "Stg" ? item.bluntResST : item.bluntRes;
        default:
          return 1;
      }
    },
    ctxc(ctx1, ctx2) {
      if (ctx1.result == "X" || ctx1.result < ctx2.result) {
        return "cm-clash-lose";
      }

      if (ctx1.result > ctx2.result || ctx2.result == "X") {
        return "cm-clash-win";
      }

      return "cm-clash-draw";
    },
    gst(system, name) {
      let status = system.statusEffects.find(x => x.name == name);

      if (status != null) {
        return status;
      }

      return {
        name: name,
        count: 0,
        nextRoundCount: 0
      }
    },
    uts(text) {
      return text.replace("_", " ");
    },
    checkCosts(actor, costs, light = 0) {
      if (actor.system.attributes.light.value < light) {
        return false;
      }
      
      for (const cost of costs) {
        if (cost.status == "Bloodfeast") {
          return actor.canSpendBloodfeast(actor.getModifiedBloodfeastCost(cost.cost));
        }
        else {
          if (actor.getStatusCount(cost.status) < cost.cost) {
            return false;
          }
        }
      }

      return true;
    },
    recycleable(actor) {
      return actor.system.recycleAction != null;
    },
    getRecycleContext(action) {
      let ctx = fixRollContext(action.context);
      return {
        context: ctx,
        item: action.source,
        type: action.type,
        description: enrichClashData(ctx.getDescription())
      };
    },
    hasAugment(actor, name) {
      return searchByObject(actor).augmentEffectCount(name) != 0;
    }
  });

  handleBarReplacement();

  Handlebars.registerPartial('ptEffect', '{{> systems/pmttrpg/templates/item/parts/effect.hbs}}')
  Handlebars.registerPartial('ptWeaponBlock', '{{> systems/pmttrpg/templates/item/parts/weapon-block.hbs}}')
  Handlebars.registerPartial('ptOutfitBlock', '{{> systems/pmttrpg/templates/item/parts/outfit-block.hbs}}')
  Handlebars.registerPartial('ptSkillBlock', '{{> systems/pmttrpg/templates/item/parts/skill-block.hbs}}')
  Handlebars.registerPartial('ptToolBlock', '{{> systems/pmttrpg/templates/item/parts/tool-block.hbs}}')
  Handlebars.registerPartial('ptTechniqueBlock', '{{> systems/pmttrpg/templates/item/parts/technique-block.hbs}}')
  Handlebars.registerPartial('ptSkillCosts', '{{> systems/pmttrpg/templates/item/parts/skill-costs.hbs}}')
  Handlebars.registerPartial('ptConditionalCosts', '{{> systems/pmttrpg/templates/item/parts/conditional-costs.hbs}}')
  return preloadHandlebarsTemplates();
});

export function fixRollContext(context) {
  let ctx = new RollContext();
  Object.assign(ctx, context);
  ctx.fix();
  return ctx;
}

export function playSound(key, global = true) {
  let path = `systems/pmttrpg/assets/audio/${key}.mp3`;
  if (global) {
    foundry.audio.AudioHelper.play({ src: path }, true);
  }
  else {
    game.audio.play(path);
  }
}


// https://stackoverflow.com/a/873856
export function generateUUID()
{
    // http://www.ietf.org/rfc/rfc4122.txt
    var s = [];
    var hexDigits = "0123456789abcdef";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
    s[8] = s[13] = s[18] = s[23] = "-";

    var uuid = s.join("");
    return uuid;
}

export function getBloodfeast() {
  return game.settings.get('pmttrpg', 'bloodfeast');
}

export async function setBloodfeast(val) {
  if (val < 0) {
    val = 0;
  }

  await game.settings.set('pmttrpg', 'bloodfeast', val);
}

export async function addBloodfeast(val) {
  let cur = getBloodfeast();
  await setBloodfeast(cur + val);
}

export async function reduceBloodfeast(val) {
  let cur = getBloodfeast();
  await setBloodfeast(cur - val);
}

Hooks.on(`createChatMessage`, (message, action, id) => {
  if (message.title == "NETMSGFLAG") {
    handler[message.flavor](JSON.parse(message.content));
  }
});

Hooks.on(`controlToken`, async (token, data) => {
  if (canvas.tokens.controlled[0] == token) {
    await token.actor.refreshMacroBar();
  }
});

Hooks.on(`renderChatMessageHTML`, (message, html, context) => {
  if (message.title == "NETMSGFLAG") {
    hideChatMessage(html);
  }
});

Hooks.on(`combatRound`, async (combat, data, options) => {
  await roundChange(combat, data.round, data.turn);
});

Hooks.on(`combatTurnChange`, async (combat, data, data2) => {
  await turnChange(combat, 0, data2);
});

Hooks.on(`combatStart`, async (combat, data) => {
  setBloodfeast(0);
  await roundChange(combat, data.round, data.turn);
});

Hooks.on(`updateCombatant`, async (combatant, data, options, id) => {
  await updateCombatant(combatant, data, id);
});

Hooks.once('ready', () => {
  setRound(game.combat.round, game.combat.turn);
});

Hooks.on('preMoveToken', (token, data, action, user) => {
  let distScale = canvas.grid.size;
  let origin = data.origin;
  let dest = data.destination;
  let dist = distanceBetween(origin, dest);
  let sqr = Math.floor(dist / distScale) + (Math.max((data.destination.elevation - data.origin.elevation) / 5, 0));

  if (token.movementAction != "blink" && sqr > token.actor.system.movement && (game.combat != null && game.combat.isActive) && getActorUser(token.actor) == game.user && !token.actor.getRiding()) {
    ui.notifications.notify(`You cant move that far! You attempted to move ${sqr} SQR, while only having ${token.actor.system.movement} SQR remaining!`);
    return false;
  }

  if (token.actor.getRiding() && (sqr <= token.actor.getMountedActor().system.movement || (game.combat == null || !game.combat.isActive)) && getActorUser(token.actor) == game.user) {
    if (ignoreNextMountFlag.includes(token.actor)) {
      ignoreNextMountFlag = ignoreNextMountFlag.filter(x => x != token.actor);
      return true;
    }

    ignoreNextMountFlag.push(token.actor.getMountedActor());
    getActorToken(token.actor.getMountedActor()).document.update(canvas.grid.getSnappedPosition(data.destination.x, data.destination.y));
    return true;
  }

  if (token.actor.getRidden() && (sqr <= token.actor.system.movement || (game.combat == null || !game.combat.isActive)) && getActorUser(token.actor) == game.user) {
    if (ignoreNextMountFlag.includes(token.actor)) {
      ignoreNextMountFlag = ignoreNextMountFlag.filter(x => x != token.actor);
      return true;
    }

    let t1 = getActorToken(token.actor.getMountedActor());

    let point = canvas.grid.getCenterPoint({x: data.destination.x, y: data.destination.y });
    point.x -= t1.mesh.canvasBounds.width / 2;
    point.y -= t1.mesh.canvasBounds.height / 2;
    
    ignoreNextMountFlag.push(token.actor.getMountedActor());
    getActorToken(token.actor.getMountedActor()).document.update({ x: point.x, y: point.y });
    return true;
  }
});

Hooks.on('moveToken', async (token, data, action, user) => {
  let distScale = canvas.grid.size;
  let origin = data.origin;
  let dest = data.destination;
  let dist = distanceBetween(origin, dest);
  let sqr = Math.floor(dist / distScale) + (Math.max((data.destination.elevation - data.origin.elevation) / 5, 0));;

  if (token.movementAction != "blink" && (game.combat != null && game.combat.isActive) && getActorUser(token.actor) == game.user && !token.actor.getRiding()) {
    if (sqr > 6 && token.actor.augmentEffectCount("Velocity Generator") > 0) {
      let movement = sqr - 6;
      await token.actor.applyStatus("Charge", movement);
      createEffectsMessage(token.actor.name, `Gains ${movement} [/status/Charge] Charge from Velocity Generator!`);
    }

    await token.actor.update({ "system.movement": Math.max(Number(token.actor.system.movement) - sqr, 0) }, { diff: false });
    await token.actor.fireStatusEffects(Triggers.MOVE);
  }
});

function distanceBetween(v1, v2) {
  return Math.hypot(v2.x - v1.x, v2.y - v1.y);
}

export function scale(distance) {
  return Math.floor(distance / canvas.grid.distance);
}

/**
 * @param {HTMLElement} html
 */
function hideChatMessage(html) {
  while (html.firstChild != null) {
    html.removeChild(html.firstChild);
  }

  html.remove();
  html.style.setProperty("display", "none", "important");
}

export function findItemOwner(item) {
  for (const token of canvas.tokens.placeables) {
    if (token.actor == null) continue;
    for (const aItem of token.actor.items) {
      if (aItem._id == item._id) {
        return token.actor;
      }
    }
  }

  for (const actor of game.actors) {
    for (const aItem of actor.items) {
      if (aItem._id == item._id) {
        return actor;
      }
    }
  }

  return null;
}

export function findOfTypeForActor(actor, type) {
  for (const aItem of actor.items) {
    if (aItem.type == type) {
      return aItem;
    }
  }

  return null;
}

export function searchByObject(actor) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == actor.system.id) {
        return token.actor;
      }
    }
  }

  return game.actors.get(actor._id);
}

export function getActorToken(actor) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == actor.system.id) {
        return token;
      }
    }
  }

  return null;
}

export function searchForActor(id) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == id) {
        return token.actor;
      }
    }
  }

  return game.actors.get(id);
}

export function findBoundActors(actor) {
  let id = actor.system.id;
  let results = [];

  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.settings.linkedActor == id) {
        results.push(token.actor);
      }
    }
  }

  for (let x of game.actors) {
    if (!results.includes(x) && x.system.settings.linkedActor == id) {
      results.push(x);
    }
  }

  return results;
}

export function getDistance(actor1, actor2) {
  let token1 = canvas.tokens.placeables.find(x => x.actor == actor1);
  let token2 = canvas.tokens.placeables.find(x => x.actor == actor2);
  return scale(canvas.grid.measureDistance(token1, token2));
}

export function getAlliesWithinRadiusOfTarget(actor, target, radius) {
  let actors = [];
  let source = canvas.tokens.placeables.find(x => x.actor == target);
  let dispo = 0;
  if (actor != null) {
      dispo = canvas.tokens.placeables.find(x => x.actor == actor).document.disposition;
  }

  for (let token of canvas.tokens.placeables.filter(x => x.document.disposition == dispo)) {
    if (scale(canvas.grid.measureDistance(source, token)) <= radius && token.actor != actor) {
      if (!actors.includes(token.actor)) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getAlliesWithinRadius(actor, radius) {
  let actors = [];
  let source = canvas.tokens.placeables.find(x => x.actor == actor);
  let dispo = 0;
  if (actor != null) {
      dispo = canvas.tokens.placeables.find(x => x.actor == actor).document.disposition;
  }

  for (let token of canvas.tokens.placeables.filter(x => x.document.disposition == dispo)) {
    if (scale(canvas.grid.measureDistance(source, token)) <= radius && token.actor != actor) {
      if (!actors.includes(token.actor)) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getCharactersWithinRadius(actor, radius) {
  let actors = [];
  let source = canvas.tokens.placeables.find(x => x.actor == actor);

  for (let token of canvas.tokens.placeables) {
    if (scale(canvas.grid.measureDistance(source, token)) <= radius) {
      if (!actors.includes(token.actor) && token.actor != actor) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getEnemiesWithinRadius(actor, radius) {
  let actors = [];
  let source = canvas.tokens.placeables.find(x => x.actor == actor);
  let dispo = 0;
  if (actor != null) {
      dispo = canvas.tokens.placeables.find(x => x.actor == actor).document.disposition;
  }

  for (let token of canvas.tokens.placeables.filter(x => x.document.disposition != dispo)) {
    if (scale(canvas.grid.measureDistance(source, token)) <= radius) {
      if (!actors.includes(token.actor)) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function findActorsOfTeam(actor) {
  let team = getActorTeam(actor);
  let actors = [];

  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id != actor.system.id && token.document.disposition == team) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getActorTeam(actor) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == actor.system.id) {
        return token.document.disposition;
      }
    }
  }

  return -1;
}

export function roughSizeOfObject(object) {
  const objectList = [];
  const stack = [object];
  let bytes = 0;

  while (stack.length) {
    const value = stack.pop();

    switch (typeof value) {
      case 'boolean':
        bytes += 4;
        break;
      case 'string':
        bytes += value.length * 2;
        break;
      case 'number':
        bytes += 8;
        break;
      case 'object':
        if (!objectList.includes(value)) {
          objectList.push(value);
          for (const prop in value) {
            if (value.hasOwnProperty(prop)) {
              stack.push(value[prop]);
            }
          }
        }
        break;
    }
  }

  return bytes;
}

const preloadHandlebarsTemplates = async function () {
  return loadTemplates([
    'systems/pmttrpg/templates/actor/parts/actor-stats.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-weapons.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-outfits.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-skills.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-tools.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-status.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-combat.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-augments.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-settings.hbs',
    //
    'systems/pmttrpg/templates/item/parts/effect.hbs',
    'systems/pmttrpg/templates/item/parts/resist-type.hbs',
    'systems/pmttrpg/templates/item/parts/skill-costs.hbs',
    'systems/pmttrpg/templates/item/parts/conditional-costs.hbs',
    //
    'systems/pmttrpg/templates/dialog/clash-response.hbs',
    'systems/pmttrpg/templates/dialog/clash-message.hbs',
    'systems/pmttrpg/templates/dialog/clash-result.hbs',
    'systems/pmttrpg/templates/dialog/clash-effects.hbs',
    //
    'systems/pmttrpg/templates/dialog/input-text.hbs',
    'systems/pmttrpg/templates/dialog/input-confirm.hbs',
    //
    'systems/pmttrpg/templates/item/parts/weapon-block.hbs',
    'systems/pmttrpg/templates/item/parts/skill-block.hbs',
    'systems/pmttrpg/templates/item/parts/outfit-block.hbs',
    'systems/pmttrpg/templates/item/parts/technique-block.hbs',
    'systems/pmttrpg/templates/item/parts/tool-block.hbs',
  ]);
};