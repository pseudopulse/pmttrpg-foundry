import { weaponEffects, setWeaponEffects } from "./core/effects/weaponEffects.mjs";
import { PTActor } from "./documents/actor.mjs";
import { getRollContextFromData, PTItem } from "./documents/item.mjs";
import { PTActorSheet } from "./sheets/actor.mjs";
import { PTItemSheet } from "./sheets/item.mjs";
import { handler, sendNetworkMessage, registerMessages, getActorUser, testUserPermission } from "./core/helpers/netmsg.mjs";
import { currentRound, currentTurn, roundChange, setRound, turnChange, updateCombatant, getCombatantTokens, isActorCombatant } from "./core/combat/combatState.mjs";
import { getEffectsArray } from "./core/effects/effectHelpers.mjs";
import { RollContext } from "./core/combat/rollContext.mjs";
import { createEffectsMessage, enrichClashData } from "./core/helpers/clash.mjs";
import { createAlertBox } from "./core/helpers/dialog.mjs";
import { PTTokenRuler } from "./documents/tokenRuler.mjs";
import { macroList } from "./core/combat/macros.mjs";
import { Triggers } from "./core/status/statusEffect.mjs";
import { handleBarReplacement } from "./core/combat/bars.mjs";
import { loadAllHazards, getHazardCountBetweenTwoPoints, HazardType, handleHazardMovement, clearHazards } from "./core/combat/hazards.mjs";
import { skillEffects } from "./core/effects/skillEffects.mjs";
import { quickHUDHooks } from "./core/combat/quickHUD.mjs";
// import Hooks from "@client/helpers/hooks.mjs";

let ignoreNextMountFlag = [];
let tooltip = null;

let currentPlayerActor = null;

Hooks.once("init", async () => {
  // debug
  // CONFIG.debug.hooks = true;

  game.pmttrpg = {
    macroList: macroList
  };

  //
  registerMessages();

  //
  await game.settings.register('pmttrpg', 'bloodfeast', {
    name: 'bloodfeast',
    hint: 'internal dont touch',
    config: false,
    scope: 'world',
    type: Number,
    default: 0,
    requiresReload: false
  });

  await game.settings.register('pmttrpg', 'hazards', {
    name: 'hazards',
    hint: 'internal dont touch',
    config: false,
    scope: 'world',
    type: String,
    default: "",
    requiresReload: false
  });

  await game.settings.register('pmttrpg', 'keepBloodfeast', {
    name: 'Preserve Bloodfeast',
    hint: 'Prevents Bloodfeast from clearing when combat starts.',
    config: true,
    scope: 'world',
    type: Boolean,
    default: false,
    requiresReload: false
  });

  // actor stuff
  CONFIG.Actor.documentClass = PTActor;
  CONFIG.Actor.types = ["character"];

  CONFIG.Actor.trackableAttributes = {
    character: {
      bar: ["health", "stagger", "sanity"],
      value: ["xp"]
    },
  };

  Actors.unregisterSheet('core', ActorSheet);
  Actors.registerSheet('pmttrpg', PTActorSheet,
    {
      types: ["character"],
      makeDefault: true,
      label: 'PMTTRPG.SheetLabels.Actor'
    }
  );

  // item stuff
  CONFIG.Item.documentClass = PTItem;
  CONFIG.Item.types = ["weapon", "tool", "skill", "outfit", "augment", "technique"];

  Items.unregisterSheet('core', ItemSheet);
  Items.registerSheet('pmttrpg', PTItemSheet,
    {
      types: ["weapon", "tool", "skill", "outfit", "augment", "technique"],
      makeDefault: true,
      label: 'PMTTRPG.SheetLabels.Item'
    }
  )

  // combat
  CONFIG.Combat.initiative = {
    formula: '1d6 + @abilities.Justice.value + @initiativeModifier',
    decimals: 2
  };
  CONFIG.ActiveEffect.legacyTransferral = false;

  CONFIG.Token.rulerClass = PTTokenRuler;

  // handlebar utils
  Handlebars.registerHelper({
    eq: (v1, v2) => v1 === v2,
    ne: (v1, v2) => v1 !== v2,
    lt: (v1, v2) => v1 < v2,
    gt: (v1, v2) => v1 > v2,
    lte: (v1, v2) => v1 <= v2,
    gte: (v1, v2) => v1 >= v2,
    and() {
      return Array.prototype.every.call(arguments, Boolean);
    },
    or() {
      return Array.prototype.slice.call(arguments, 0, -1).some(Boolean);
    },
    effect(name, type) {
      return getEffectsArray(type).find(x => x.name == name);

      return null;
    },
    canShowEffect(name, type) {
      let effect = getEffectsArray(type).find(x => x.name == name);

      if (effect.hidden && !game.user.isGM) {
        return false;
      }

      return effect != null;
    },
    rctx(item) {
      let ctx = getRollContextFromData(item);
      ctx.item = item;
      return ctx;
    },
    ecd(item) {
      let ctx = getRollContextFromData(item);
      if (item.type == "skill" || item.type == "tool") {
        return ctx.getDescription();
      }
      else {
        return `1d${ctx.diceMax}+${ctx.dicePower}\n` + ctx.getDescription();
      }
    },
    drctx(item, type) {
      return getRollContextFromData(item, true, type);
    },
    reslook(item, type, cat) {
      switch (type) {
        case "Slash":
          return cat == "Stg" ? item.slashResST : item.slashRes;
        case "Pierce":
          return cat == "Stg" ? item.pierceResST : item.pierceRes;
        case "Blunt":
          return cat == "Stg" ? item.bluntResST : item.bluntRes;
        default:
          return 1;
      }
    },
    ctxc(ctx1, ctx2) {
      if (ctx1.result == "X" || ctx1.result < ctx2.result) {
        return "cm-clash-lose";
      }

      if (ctx1.result > ctx2.result || ctx2.result == "X") {
        return "cm-clash-win";
      }

      return "cm-clash-draw";
    },
    gst(system, name) {
      let status = system.statusEffects.find(x => x.name == name);

      if (status != null) {
        return status;
      }

      return {
        name: name,
        count: 0,
        nextRoundCount: 0
      }
    },
    uts(text) {
      return text.replace("_", " ");
    },
    checkCosts(actor, costs, light = 0) {
      if (actor.system.attributes.light.value < light) {
        return false;
      }

      for (const cost of costs) {
        if (cost.status == "Bloodfeast") {
          return actor.canSpendBloodfeast(actor.getModifiedBloodfeastCost(cost.cost));
        }
        if (cost.status == "Discard") {
          return actor.canDiscardReactions(cost.cost);
        }
        else {
          if (actor.getStatusCount(cost.status) < cost.cost) {
            return false;
          }
        }
      }

      return true;
    },
    recycleable(actor) {
      return actor.system.recycleAction != null;
    },
    getRecycleContext(action) {
      let ctx = fixRollContext(action.context);
      return {
        context: ctx,
        item: action.source,
        type: action.type,
        description: enrichClashData(ctx.getDescription())
      };
    },
    hasAugment(actor, name) {
      return searchByObject(actor).augmentEffectCount(name) != 0;
    }
  });

  handleBarReplacement();

  setWeaponEffects(weaponEffects.concat(skillEffects.filter(x => weaponEffects.find(y => y.name == x.name) == null)));

  tooltip = document.createElement("div");
  tooltip.className = "tooltip";
  tooltip.style.position = "fixed";
  tooltip.style.pointerEvents = "none";
  document.body.appendChild(tooltip);

  document.addEventListener("mouseover", (event) => {
    const target = event.target.closest("[data-tip]");

    if (!target) return;

    showTooltip(target, target.dataset.tip, target.dataset.useTipOffset, target.dataset.tipOffset, target.dataset.tipWidth);
  });

  document.addEventListener("mouseout", (event) => {
    const target = event.target.closest("[data-tip]");

    if (!target) return;

    hideTooltip();
  });

  // quickHUDHooks();

  Handlebars.registerPartial('ptEffect', '{{> systems/pmttrpg/templates/item/parts/effect.hbs}}')
  Handlebars.registerPartial('ptWeaponBlock', '{{> systems/pmttrpg/templates/item/parts/weapon-block.hbs}}')
  Handlebars.registerPartial('ptOutfitBlock', '{{> systems/pmttrpg/templates/item/parts/outfit-block.hbs}}')
  Handlebars.registerPartial('ptSkillBlock', '{{> systems/pmttrpg/templates/item/parts/skill-block.hbs}}')
  Handlebars.registerPartial('ptToolBlock', '{{> systems/pmttrpg/templates/item/parts/tool-block.hbs}}')
  Handlebars.registerPartial('ptTechniqueBlock', '{{> systems/pmttrpg/templates/item/parts/technique-block.hbs}}')
  Handlebars.registerPartial('ptSkillCosts', '{{> systems/pmttrpg/templates/item/parts/skill-costs.hbs}}')
  Handlebars.registerPartial('ptConditionalCosts', '{{> systems/pmttrpg/templates/item/parts/conditional-costs.hbs}}')
  return preloadHandlebarsTemplates();
});

/*document.addEventListener("click", (event) => {
  if (event.button != 0) return;
  let point = screenToWorld(event.clientX, event.clientY);
  let selected = getCombatantTokens().find(x => {
    if (x.actor == null) return;
    let bounds = x.mesh._canvasBounds;

    return point.x > bounds.minX && point.x < bounds.maxX &&
      point.y > bounds.minY && point.y < bounds.maxY;
  });

  if (selected != null && testUserPermission(selected.actor, game.user)) {
    currentPlayerActor = selected.actor;
  }
})*/

function screenToWorld(x, y) {
    let transform = canvas.app.stage.worldTransform;
    x = (x - transform.tx) / canvas.stage.scale.x;
    y = (y - transform.ty) / canvas.stage.scale.y;
    
    return { x: x, y: y }; 
}

export function getPlayerActor() {
  if (currentPlayerActor == null) {
    currentPlayerActor = game.user.character;
  }

  return currentPlayerActor;
}

function showTooltip(target, text, useOffset, tipOffset, width) {
  tooltip.innerHTML = enrichClashData(text, true);

  if (width != null) {
    tooltip.style.maxWidth = width;
  }

  const rect = target.getBoundingClientRect();
  const tooltipRect = tooltip.getBoundingClientRect();

  let left = rect.left + rect.width / 2 - tooltipRect.width / 2;
  let topPoint = rect.bottom + 8;

  if (useOffset) {
    const targetCenter = rect.left + rect.width / 2;

    if (targetCenter > window.innerWidth / 2) {
      console.log("left");
      left = rect.left - tooltipRect.width - tipOffset;
    } else {
      console.log("right");
      left = rect.right + tooltipRect.width / 3 + tipOffset;
    }

    topPoint = rect.top + rect.height / 2 - tooltipRect.height / 2;
  }
  else {
    left = Math.max(
      8,
      Math.min(left, window.innerWidth - tooltipRect.width - 8)
    );
  }

  tooltip.style.top = `${topPoint}px`;
  tooltip.style.left = `${left}px`;
  tooltip.classList.add("visible");
}

function hideTooltip() {
  tooltip.classList.remove("visible");
}

export async function updateHazards(hazards) {
  await game.settings.set('pmttrpg', 'hazards', safeJsonConvert(hazards, ["display"]));
}

function safeJsonConvert(obj, ignore) {
  const res = JSON.stringify(obj, (key, value) => {
    if (ignore.includes(key)) {
      return null;
    }

    return value;
  })

  return res;
}

function getActorMovementArray(actor) {
  if (ignoreMovementConsumptionCount[actor] == null) {
    ignoreMovementConsumptionCount[actor] = [];
  }

  return ignoreMovementConsumptionCount[actor];
}

export function loadHazards() {
  let str = game.settings.get('pmttrpg', 'hazards');
  if (str == null || str == "") {
    return [];
  }
  return JSON.parse(str);
}

export function fixRollContext(context) {
  let ctx = new RollContext();
  Object.assign(ctx, context);
  ctx.fix();
  return ctx;
}

export function getTokenCenter(token) {
  let bounds = token.mesh.canvasBounds;
  let point = { x: bounds.x, y: bounds.y };
  point.x += bounds.width / 2;
  point.y += bounds.height / 2;

  return point;
}

export function playSound(key, global = true) {
  let path = `systems/pmttrpg/assets/audio/${key}.mp3`;
  if (global) {
    foundry.audio.AudioHelper.play({ src: path }, true);
  }
  else {
    game.audio.play(path);
  }
}

// https://stackoverflow.com/a/873856
export function generateUUID() {
  // http://www.ietf.org/rfc/rfc4122.txt
  var s = [];
  var hexDigits = "0123456789abcdef";
  for (var i = 0; i < 36; i++) {
    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
  }
  s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
  s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
  s[8] = s[13] = s[18] = s[23] = "-";

  var uuid = s.join("");
  return uuid;
}

export function clearLastToken() {
  lastClickedToken = null;
}

export function getBloodfeast() {
  return game.settings.get('pmttrpg', 'bloodfeast');
}

export async function setBloodfeast(val) {
  if (val < 0) {
    val = 0;
  }

  await game.settings.set('pmttrpg', 'bloodfeast', val);
}

export async function addBloodfeast(val) {
  let cur = getBloodfeast();
  await setBloodfeast(cur + val);
}

export async function reduceBloodfeast(val) {
  let cur = getBloodfeast();
  await setBloodfeast(cur - val);
}

Hooks.on("updateActor", (actor) => {
  updateActor(actor, false);
});

Hooks.on("createToken", (token) => {
  if (!token.actorLink) {
    updateActor(token.actor, false, true);
  }
});

async function updateActor(actor, forceSync, forceRegen = false) {
  if (actor != null && game.user.isActiveGM) {
    const system = actor.toObject(false).system;
    if (system.id == null || forceRegen) {
      system.id = generateUUID();
      await actor.update({ system }, { diff: true });
    }
    else if (forceSync) {
      await actor.update({ system }, { diff: true });
    }
  }
}

Hooks.on(`createChatMessage`, (message, action, id) => {
  if (message.title == "NETMSGFLAG") {
    handler[message.flavor](JSON.parse(message.content));
  }
});

Hooks.on(`controlToken`, async (token, data) => {
  if (canvas.tokens.controlled[0] == token) {
    await token.actor.refreshMacroBar();
  }
});

Hooks.on(`renderChatMessageHTML`, (message, html, context) => {
  if (message.title == "NETMSGFLAG") {
    hideChatMessage(html);
  }
});

Hooks.on(`updateCombat`, async (combat, data, options) => {
  if (data.round == undefined) {
    return;
  }

  // await roundChange(combat, data.round, data.turn);
});

Hooks.on('preUpdateCombat', async (combat, data, data2) => {
  if (data.round == undefined) {
    return;
  }
  
  await roundChange(combat, data.round, data.turn);
});

Hooks.on(`combatTurnChange`, async (combat, data, data2) => {
  await turnChange(combat, 0, data2);
});

Hooks.on(`combatStart`, async (combat, data) => {
  if (!game.settings.get('pmttrpg', 'keepBloodfeast')) {
    await setBloodfeast(0);
  }
  await updateHazards([]);
  clearHazards();
  await roundChange(combat, data.round, data.turn);
});

Hooks.on(`updateCombatant`, async (combatant, data, options, id) => {
  await updateCombatant(combatant, data, id);
});

Hooks.once('ready', () => {
  if (game.combat != null) {
    setRound(game.combat.round, game.combat.turn);
  }

  for (const token of canvas.tokens.placeables) {
    if (token.actor == null) continue;
    updateActor(token.actor, true);
  }

  loadAllHazards();
});

export function centerPosition(point) {
  return {
    x: point.x + (canvas.grid.size / 2),
    y: point.y + (canvas.grid.size / 2)
  };
}

Hooks.on('preMoveToken', (token, data, action, user) => {
  let distScale = canvas.grid.size;
  let origin = data.origin;
  let dest = data.destination;
  let dist = distanceBetween(origin, dest);
  let difficultTerrainMoved = getHazardCountBetweenTwoPoints(HazardType.DIFFICULT_TERRAIN, centerPosition(origin), centerPosition(dest));
  if (dest.elevation != origin.elevation) {
    difficultTerrainMoved = 0;
  }

  let sqr = Math.floor(dist / distScale) + (Math.max((data.destination.elevation - data.origin.elevation) / 5, 0)) + difficultTerrainMoved;
  let baseSqr = Math.floor(dist / distScale);

  if (token.getFlag("pmttrpg", "ignoreNextMovementCheck")) {
    return true;
  }

  if (token.movementAction != "blink" && sqr > token.actor.system.movement && (game.combat != null && game.combat.isActive) && getActorUser(token.actor) == game.user && !token.actor.getRiding()) {
    ui.notifications.notify(`You cant move that far! You attempted to move ${sqr} SQR, while only having ${token.actor.system.movement} SQR remaining!`);
    return false;
  }

  if (token.actor.getRiding() && (sqr <= token.actor.getMountedActor().system.movement || (game.combat == null || !game.combat.isActive)) && getActorUser(token.actor) == game.user) {
    if (ignoreNextMountFlag.includes(token.actor)) {
      ignoreNextMountFlag = ignoreNextMountFlag.filter(x => x != token.actor);
      return true;
    }

    ignoreNextMountFlag.push(token.actor.getMountedActor());
    getActorToken(token.actor.getMountedActor()).document.update(canvas.grid.getSnappedPosition(data.destination.x, data.destination.y));
    return true;
  }

  if (token.actor.getRidden() && (sqr <= token.actor.system.movement || (game.combat == null || !game.combat.isActive)) && getActorUser(token.actor) == game.user) {
    if (ignoreNextMountFlag.includes(token.actor)) {
      ignoreNextMountFlag = ignoreNextMountFlag.filter(x => x != token.actor);
      return true;
    }

    let t1 = getActorToken(token.actor.getMountedActor());

    let point = canvas.grid.getCenterPoint({ x: data.destination.x, y: data.destination.y });
    point.x -= t1.mesh.canvasBounds.width / 2;
    point.y -= t1.mesh.canvasBounds.height / 2;

    ignoreNextMountFlag.push(token.actor.getMountedActor());
    getActorToken(token.actor.getMountedActor()).document.update({ x: point.x, y: point.y });
    return true;
  }
});

Hooks.on('moveToken', async (token, data, action, user) => {
  let distScale = canvas.grid.size;
  let origin = data.origin;
  let dest = data.destination;
  let dist = distanceBetween(origin, dest);
  let difficultTerrainMoved = getHazardCountBetweenTwoPoints(HazardType.DIFFICULT_TERRAIN, centerPosition(origin), centerPosition(dest));
  if (dest.elevation != origin.elevation) {
    difficultTerrainMoved = 0;
  }

  let sqr = Math.floor(dist / distScale) + (Math.max((data.destination.elevation - data.origin.elevation) / 5, 0)) + difficultTerrainMoved;
  let baseSqr = Math.floor(dist / distScale);

  if (token.movementAction != "blink" && (game.combat != null && game.combat.isActive) && getActorUser(token.actor) == game.user && !token.actor.getRiding() && !token.getFlag("pmttrpg", "ignoreNextMovementCheck")) {
    if (sqr > 6 && token.actor.augmentEffectCount("Velocity Generator") > 0) {
      let movement = sqr - 6;
      await token.actor.applyStatus("Charge", movement);
      createEffectsMessage(token.actor.name, `Gains ${movement} [/status/Charge] Charge from Velocity Generator!`);
    }

    await token.actor.update({ "system.movement": Math.max(Number(token.actor.system.movement) - sqr, 0) }, { diff: true });
    await token.actor.fireStatusEffects(Triggers.MOVE);
    if (dest.elevation == origin.elevation) {
      await handleHazardMovement(token, centerPosition(origin), centerPosition(dest));
    }
  }

  if (token.getFlag("pmttrpg", "ignoreNextMovementCheck") && getActorUser(token.actor) == game.user) {
    await token.setFlag("pmttrpg", "ignoreNextMovementCheck", false);
    await token.update({ movementAction: "walk" }, { render: true, diff: true });

    if (dest.elevation == origin.elevation) {
      await handleHazardMovement(token, centerPosition(origin), centerPosition(dest));
    }
  }
});

function distanceBetween(v1, v2) {
  return Math.hypot(v2.x - v1.x, v2.y - v1.y);
}

export function gridDistanceBetween(v1, v2) {
  return Math.hypot(v2.x - v1.x, v2.y - v1.y) / canvas.grid.size;
}

export function scale(distance) {
  return Math.floor(distance / canvas.grid.distance);
}

/**
 * @param {HTMLElement} html
 */
function hideChatMessage(html) {
  while (html.firstChild != null) {
    html.removeChild(html.firstChild);
  }

  html.remove();
  html.style.setProperty("display", "none", "important");
}

export function findItemOwner(item) {
  for (const token of canvas.tokens.placeables) {
    if (token.actor == null) continue;
    for (const aItem of token.actor.items) {
      if (aItem._id == item._id) {
        return token.actor;
      }
    }
  }

  for (const actor of game.actors) {
    for (const aItem of actor.items) {
      if (aItem._id == item._id) {
        return actor;
      }
    }
  }

  return null;
}

export function findOfTypeForActor(actor, type) {
  for (const aItem of actor.items) {
    if (aItem.type == type) {
      return aItem;
    }
  }

  return null;
}

export function searchByObject(actor) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == actor.system.id) {
        return token.actor;
      }
    }
  }

  return game.actors.get(actor._id);
}

export function getActorToken(actor) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == actor.system.id) {
        return token;
      }
    }
  }

  return null;
}

export function searchForActor(id) {
  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.id == id) {
        return token.actor;
      }
    }
  }

  return game.actors.get(id);
}

export function findBoundActors(actor) {
  let id = actor.system.id;
  let results = [];

  if (canvas.tokens != undefined) {
    for (let token of canvas.tokens.placeables) {
      if (token.actor == null) continue;
      if (token.actor.system.settings.linkedActor == id) {
        results.push(token.actor);
      }
    }
  }

  for (let x of game.actors) {
    if (!results.includes(x) && x.system.settings.linkedActor == id) {
      results.push(x);
    }
  }

  return results;
}

export function weightedPick(items, weights) {
  const total = weights.reduce((a, b) => a + b, 0);

  if (total <= 0) return null;

  let r = Math.random() * total;

  for (let i = 0; i < items.length; i++) {
    r -= weights[i];

    if (r <= 0) {
      return i;
    }
  }

  return items.length - 1;
}

export function getDistance(actor1, actor2) {
  let token1 = canvas.tokens.placeables.find(x => x.actor == actor1);
  let token2 = canvas.tokens.placeables.find(x => x.actor == actor2);

  if (!token1 || !token2) return 0;

  let x1 = token1.document.x / canvas.grid.size;
  let y1 = token1.document.y / canvas.grid.size;
  let w1 = token1.document.width;
  let h1 = token1.document.height;

  let x2 = token2.document.x / canvas.grid.size;
  let y2 = token2.document.y / canvas.grid.size;
  let w2 = token2.document.width;
  let h2 = token2.document.height;

  let dx = Math.max(0, Math.max(x1 - (x2 + w2), x2 - (x1 + w1)));

  let dy = Math.max(0, Math.max(y1 - (y2 + h2), y2 - (y1 + h1)));

  return Math.max(dx, dy) + 1;
}

export function getAlliesWithinRadiusOfTarget(actor, target, radius) {
  if (!isActorCombatant(actor)) {
    return [];
  }

  let actors = [];
  let source = getCombatantTokens().find(x => x.actor == target);
  let dispo = 0;
  if (actor != null) {
    dispo = getCombatantTokens().find(x => x.actor == actor).document.disposition;
  }

  for (let token of getCombatantTokens().filter(x => x.document.disposition == dispo)) {
    if (scale(canvas.grid.measureDistance(source, token)) <= radius && token.actor != actor) {
      if (!actors.includes(token.actor)) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getAlliesWithinRadius(actor, radius) {
  if (!isActorCombatant(actor)) {
    return [];
  }

  let actors = [];
  let source = getCombatantTokens().find(x => x.actor == actor);
  let dispo = 0;
  if (actor != null) {
    dispo = getCombatantTokens().find(x => x.actor == actor).document.disposition;
  }

  for (let token of getCombatantTokens().filter(x => x.document.disposition == dispo)) {
    if (token.actor == null) continue;
    if (scale(canvas.grid.measureDistance(source, token)) <= radius && token.actor != actor) {
      if (!actors.includes(token.actor)) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getCharactersWithinRadius(actor, radius) {
  if (!isActorCombatant(actor)) {
    return [];
  }

  let actors = [];
  let source = getCombatantTokens().find(x => x.actor == actor);

  for (let token of getCombatantTokens()) {
    if (token.actor == null) continue;
    if (scale(canvas.grid.measureDistance(source, token)) <= radius) {
      if (!actors.includes(token.actor) && token.actor != actor) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getEnemiesWithinRadius(actor, radius) {
  if (!isActorCombatant(actor)) {
    return [];
  }

  let actors = [];
  let source = getCombatantTokens().find(x => x.actor == actor);
  let dispo = 0;
  if (actor != null) {
    dispo = getCombatantTokens().find(x => x.actor == actor).document.disposition;
  }

  for (let token of getCombatantTokens().filter(x => x.document.disposition != dispo)) {
    if (token.actor == null) continue;
    if (scale(canvas.grid.measureDistance(source, token)) <= radius) {
      if (!actors.includes(token.actor)) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function findActorsOfTeam(actor) {
  if (!isActorCombatant(actor)) {
    return [];
  }

  let team = getActorTeam(actor);
  let actors = [];

  if (canvas.tokens != undefined) {
    for (let token of getCombatantTokens()) {
      if (token.actor == null) continue;
      if (token.actor.system.id != actor.system.id && token.document.disposition == team) {
        actors.push(token.actor);
      }
    }
  }

  return actors;
}

export function getActorTeam(actor) {
  for (let token of getCombatantTokens()) {
    if (token.actor == null) continue;
    if (token.actor.system.id == actor.system.id) {
      return token.document.disposition;
    }
  }

  return -1;
}

export function roughSizeOfObject(object) {
  const objectList = [];
  const stack = [object];
  let bytes = 0;

  while (stack.length) {
    const value = stack.pop();

    switch (typeof value) {
      case 'boolean':
        bytes += 4;
        break;
      case 'string':
        bytes += value.length * 2;
        break;
      case 'number':
        bytes += 8;
        break;
      case 'object':
        if (!objectList.includes(value)) {
          objectList.push(value);
          for (const prop in value) {
            if (value.hasOwnProperty(prop)) {
              stack.push(value[prop]);
            }
          }
        }
        break;
    }
  }

  return bytes;
}

const preloadHandlebarsTemplates = async function () {
  return loadTemplates([
    'systems/pmttrpg/templates/actor/parts/actor-stats.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-weapons.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-outfits.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-skills.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-tools.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-status.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-combat.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-augments.hbs',
    'systems/pmttrpg/templates/actor/parts/actor-settings.hbs',
    //
    'systems/pmttrpg/templates/item/parts/effect.hbs',
    'systems/pmttrpg/templates/item/parts/resist-type.hbs',
    'systems/pmttrpg/templates/item/parts/skill-costs.hbs',
    'systems/pmttrpg/templates/item/parts/conditional-costs.hbs',
    //
    'systems/pmttrpg/templates/dialog/clash-response.hbs',
    'systems/pmttrpg/templates/dialog/clash-message.hbs',
    'systems/pmttrpg/templates/dialog/clash-result.hbs',
    'systems/pmttrpg/templates/dialog/clash-effects.hbs',
    //
    'systems/pmttrpg/templates/dialog/input-text.hbs',
    'systems/pmttrpg/templates/dialog/input-confirm.hbs',
    //
    'systems/pmttrpg/templates/item/parts/weapon-block.hbs',
    'systems/pmttrpg/templates/item/parts/skill-block.hbs',
    'systems/pmttrpg/templates/item/parts/outfit-block.hbs',
    'systems/pmttrpg/templates/item/parts/technique-block.hbs',
    'systems/pmttrpg/templates/item/parts/tool-block.hbs',
  ]);
};